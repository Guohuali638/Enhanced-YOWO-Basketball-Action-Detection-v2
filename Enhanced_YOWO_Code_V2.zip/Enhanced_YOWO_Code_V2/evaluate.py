#!/usr/bin/env python
import argparse
import json
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import DataLoader

from enhanced_yowo.data import VideoActionDataset, detection_collate
from enhanced_yowo.models import build_model
from enhanced_yowo.engine import evaluate_frame
from enhanced_yowo.utils.common import load_config, get_device, save_json
from enhanced_yowo.utils.metrics import build_tubes, video_map


def to_list(x):
    if isinstance(x, np.ndarray): return x.tolist()
    if torch.is_tensor(x): return x.detach().cpu().tolist()
    return x


def main():
    p=argparse.ArgumentParser(description='Evaluate Enhanced YOWO and save verifiable machine-readable outputs.')
    p.add_argument('--config',required=True); p.add_argument('--manifest',required=True); p.add_argument('--checkpoint',required=True)
    p.add_argument('--output',required=True); p.add_argument('--predictions-output',default=None); p.add_argument('--sources',nargs='*',default=None)
    a=p.parse_args(); cfg=load_config(a.config); dev=get_device(cfg.get('device','cuda'))
    ds=VideoActionDataset(a.manifest,cfg['image_size'],cfg['clip_len'],cfg.get('frame_stride',1),False,allowed_sources=a.sources)
    dl=DataLoader(ds,batch_size=cfg['batch_size'],shuffle=False,num_workers=cfg['num_workers'],pin_memory=True,collate_fn=detection_collate)
    model=build_model(cfg).to(dev); ck=torch.load(a.checkpoint,map_location='cpu'); model.load_state_dict(ck['model'])
    fm, pc, rec=evaluate_frame(model,dl,cfg,dev)
    ep=cfg.get('evaluation_protocol',{})
    result={
        'frame_map':float(fm),
        'per_class_ap':{str(k):float(v) for k,v in pc.items()},
        'evaluation_protocol':{
            'frame_map_iou':float(cfg.get('frame_map_iou',ep.get('frame_map_iou',0.5))),
            'score_threshold':float(cfg.get('score_threshold',0.05)),
            'nms_iou_threshold':float(cfg.get('nms_iou_threshold',0.5)),
            'ap_method':ep.get('ap_method','interpolated_precision_recall_integral'),
            'official_split_id':ep.get('official_split_id'),
        }
    }
    pred_records=[]
    pred_frames=[]; gt_frames=[]
    for r in rec:
        item={
            'video_id':r['video_id'],'frame_index':int(r['frame_index']),
            'pred_boxes':to_list(r['pred_boxes']),'pred_labels':to_list(r['pred_labels']),'pred_scores':to_list(r['pred_scores']),
            'gt_boxes':to_list(r['gt_boxes']),'gt_labels':to_list(r['gt_labels']),'gt_track_ids':to_list(r.get('gt_track_ids',[])),
        }
        pred_records.append(item)
        pred_frames.append({'video_id':r['video_id'],'frame_index':r['frame_index'],'boxes':r['pred_boxes'],'labels':r['pred_labels'],'scores':r['pred_scores']})
        gt_frames.append({'video_id':r['video_id'],'frame_index':r['frame_index'],'boxes':r['gt_boxes'],'labels':r['gt_labels'],
                          'scores':np.ones(len(r['gt_labels'])),'track_ids':r.get('gt_track_ids',np.full(len(r['gt_labels']),-1))})
    if cfg.get('video_map_thresholds'):
        link_iou=float(ep.get('prediction_tube_link_iou',0.5)); max_gap=int(ep.get('prediction_max_gap_frames',1))
        pt=build_tubes(pred_frames,iou_link=link_iou,max_gap=max_gap,use_track_ids=False)
        # Ground-truth track IDs are used when available; otherwise the same explicit linker is applied.
        gt=build_tubes(gt_frames,iou_link=link_iou,max_gap=max_gap,use_track_ids=True)
        result['video_map']={str(t):float(video_map(pt,gt,cfg['num_classes'],float(t))) for t in cfg['video_map_thresholds']}
        result['evaluation_protocol'].update({
            'prediction_tube_link_iou':link_iou,
            'prediction_max_gap_frames':max_gap,
            'video_map_thresholds':[float(t) for t in cfg['video_map_thresholds']],
            'ground_truth_track_ids_used_when_available':True,
        })
    Path(a.output).parent.mkdir(parents=True,exist_ok=True); save_json(result,a.output)
    pred_out=a.predictions_output or str(Path(a.output).with_name('predictions.json'))
    save_json({'manifest':str(Path(a.manifest).resolve()),'checkpoint':str(Path(a.checkpoint).resolve()),'records':pred_records},pred_out)
    save_json(result['evaluation_protocol'],str(Path(a.output).with_name('evaluation_protocol_used.json')))
    print(json.dumps(result,indent=2))
if __name__=='__main__': main()
