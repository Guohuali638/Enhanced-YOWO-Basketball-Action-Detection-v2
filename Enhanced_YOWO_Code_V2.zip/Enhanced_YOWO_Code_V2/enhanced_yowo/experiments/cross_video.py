#!/usr/bin/env python
import argparse, json, os, subprocess, sys
from pathlib import Path
import numpy as np

from enhanced_yowo.data import manifest_sources
from enhanced_yowo.experiments.common import best_metric_from_history


def run(cmd):
    print(' '.join(cmd)); subprocess.check_call(cmd)


def main():
    p=argparse.ArgumentParser(description='Leave-one-source-video-out experiment')
    p.add_argument('--config',required=True); p.add_argument('--manifest',required=True); p.add_argument('--output',required=True)
    p.add_argument('--baseline',action='store_true',help='Run baseline YOWO (BiFormer/SE off, original CAM fusion)')
    p.add_argument('--epochs',type=int,default=None); p.add_argument('--max-folds',type=int,default=None)
    a=p.parse_args(); out=Path(a.output); out.mkdir(parents=True,exist_ok=True)
    sources=manifest_sources(a.manifest); sources=sources[:a.max_folds] if a.max_folds else sources
    if len(sources)<2: raise ValueError('Need at least 2 distinct source_id values for source-video-disjoint evaluation')
    # create temporary config for desired variant
    import yaml
    cfg=yaml.safe_load(open(a.config))
    if a.baseline:
        cfg['model']['use_biformer']=False; cfg['model']['use_se']=False; cfg['model']['dcem_variant']='original_cam'
    cpath=out/('baseline.yaml' if a.baseline else 'enhanced.yaml'); yaml.safe_dump(cfg,open(cpath,'w'),sort_keys=False)
    rows=[]
    for i,val in enumerate(sources):
        train=[s for s in sources if s!=val]
        fold=out/f'fold_{i+1}_{val}'; fold.mkdir(exist_ok=True)
        cmd=[sys.executable,'train.py','--config',str(cpath),'--manifest',a.manifest,'--output',str(fold),'--train-sources',*train,'--val-sources',val]
        if a.epochs: cmd += ['--epochs',str(a.epochs)]
        run(cmd)
        metric=best_metric_from_history(fold/'history.json')
        rows.append({'fold':i+1,'validation_source':val,'frame_map':metric})
    vals=np.array([r['frame_map'] for r in rows])
    summary={'folds':rows,'mean':float(vals.mean()),'sd':float(vals.std(ddof=1) if len(vals)>1 else 0.0)}
    json.dump(summary,open(out/'summary.json','w'),indent=2); print(json.dumps(summary,indent=2))
if __name__=='__main__': main()
