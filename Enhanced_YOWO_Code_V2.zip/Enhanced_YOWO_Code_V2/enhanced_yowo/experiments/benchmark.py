#!/usr/bin/env python
import argparse, json, time
from datetime import datetime, timezone
from pathlib import Path
import torch

from enhanced_yowo.models import build_model
from enhanced_yowo.utils.common import load_config, get_device, model_num_parameters


def main():
    p=argparse.ArgumentParser(description='Network-only runtime benchmark with unambiguous throughput definitions.')
    p.add_argument('--config',required=True); p.add_argument('--checkpoint',required=True); p.add_argument('--output',required=True)
    p.add_argument('--warmup',type=int,default=None); p.add_argument('--runs',type=int,default=None)
    a=p.parse_args(); cfg=load_config(a.config); device=get_device(cfg.get('device','cuda'))
    bc=cfg.get('benchmark',{}); warmup=a.warmup if a.warmup is not None else int(bc.get('warmup',100)); runs=a.runs if a.runs is not None else int(bc.get('runs',500))
    model=build_model(cfg).to(device); ck=torch.load(a.checkpoint,map_location='cpu'); model.load_state_dict(ck['model']); model.eval()
    batch_size=int(bc.get('batch_size',1)); x=torch.randn(batch_size,cfg['clip_len'],3,cfg['image_size'],cfg['image_size'],device=device)
    if device.type=='cuda': torch.cuda.reset_peak_memory_stats(device)
    with torch.no_grad():
        for _ in range(warmup): model(x)
        if device.type=='cuda': torch.cuda.synchronize(device)
        t0=time.perf_counter()
        for _ in range(runs): model(x)
        if device.type=='cuda': torch.cuda.synchronize(device)
        elapsed=time.perf_counter()-t0
    latency_per_batch_ms=elapsed/runs*1000
    latency_per_clip_ms=latency_per_batch_ms/batch_size
    clips_s=1000.0/latency_per_clip_ms
    # YOWO emits one prediction set for the keyframe of each clip.
    keyframe_detections_s=clips_s
    input_frame_equivalent_fps=clips_s*int(cfg['clip_len'])
    mem=(torch.cuda.max_memory_allocated(device)/1024**3) if device.type=='cuda' else 0.0
    row={
        'created_utc':datetime.now(timezone.utc).isoformat(),
        'device':str(device),
        'gpu_name':torch.cuda.get_device_name(device) if device.type=='cuda' else None,
        'batch_size':batch_size,'clip_len':int(cfg['clip_len']),'image_size':int(cfg['image_size']),
        'warmup_passes':warmup,'measured_passes':runs,
        'parameters_M':model_num_parameters(model)/1e6,
        'latency_ms_per_clip':latency_per_clip_ms,
        'clips_per_second':clips_s,
        'keyframe_detections_per_second':keyframe_detections_s,
        'input_frame_equivalent_fps':input_frame_equivalent_fps,
        'peak_gpu_memory_GB':mem,
        'network_only':True,
        'excluded_from_timing':['video decoding','disk I/O','data loading'],
        'interpretation_note':'input_frame_equivalent_fps = clips_per_second * clip_len and must not be presented as end-to-end video FPS.'
    }
    Path(a.output).parent.mkdir(parents=True,exist_ok=True); json.dump(row,open(a.output,'w',encoding='utf-8'),indent=2); print(json.dumps(row,indent=2))
if __name__=='__main__': main()
