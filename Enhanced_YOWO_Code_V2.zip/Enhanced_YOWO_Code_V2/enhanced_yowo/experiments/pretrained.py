#!/usr/bin/env python
import argparse, subprocess, sys, json
from pathlib import Path
import yaml
from enhanced_yowo.experiments.common import best_metric_from_history


def main():
    p=argparse.ArgumentParser(description='Random vs pretrained initialization robustness')
    p.add_argument('--config',required=True); p.add_argument('--train-manifest',required=True); p.add_argument('--val-manifest',required=True)
    p.add_argument('--weights2d',required=True); p.add_argument('--weights3d',required=True); p.add_argument('--output',required=True)
    p.add_argument('--epochs',type=int,default=None)
    a=p.parse_args(); out=Path(a.output); out.mkdir(parents=True,exist_ok=True)
    base=yaml.safe_load(open(a.config))
    variants={
        'yowo': {'use_biformer':False,'use_se':False,'dcem_variant':'original_cam'},
        'enhanced': {'use_biformer':True,'use_se':True,'dcem_variant':'asymmetric'},
    }
    results={}
    for name,v in variants.items():
        cfg=yaml.safe_load(open(a.config)); cfg['model'].update(v)
        cp=out/f'{name}.yaml'; yaml.safe_dump(cfg,open(cp,'w'),sort_keys=False)
        od=out/name
        cmd=[sys.executable,'train.py','--config',str(cp),'--manifest',a.train_manifest,'--val-manifest',a.val_manifest,'--output',str(od),'--weights2d',a.weights2d,'--weights3d',a.weights3d]
        if a.epochs: cmd+=['--epochs',str(a.epochs)]
        print(' '.join(cmd)); subprocess.check_call(cmd)
        results[name]=best_metric_from_history(od/'history.json')
    json.dump(results,open(out/'summary.json','w'),indent=2); print(json.dumps(results,indent=2))
if __name__=='__main__': main()
