#!/usr/bin/env python
import argparse, json
from pathlib import Path
import numpy as np
import torch
import matplotlib.pyplot as plt

from enhanced_yowo.experiments.common import load_model_and_loader
from enhanced_yowo.utils.decode import decode_predictions
from enhanced_yowo.utils.metrics import build_tubes, tube_iou


def classify(gt,p):
    gs,ge=min(gt['frames']),max(gt['frames']); ps,pe=min(p['frames']),max(p['frames'])
    if ps>gs and pe<ge: return 'boundary_truncation'
    if ps<gs and pe>ge: return 'boundary_extension'
    overlap=set(gt['frames']) & set(p['frames'])
    if len(overlap)>0 and len(p['frames']) < 0.7*len(gt['frames']): return 'fragmentation_or_missed_frames'
    if ps>gs or pe<ge: return 'partial_boundary_error'
    return 'spatial_or_class_consistency'


def main():
    p=argparse.ArgumentParser(); p.add_argument('--config',required=True); p.add_argument('--manifest',required=True); p.add_argument('--checkpoint',required=True); p.add_argument('--output',required=True); p.add_argument('--strict-iou',type=float,default=.5)
    a=p.parse_args(); out=Path(a.output); out.mkdir(parents=True,exist_ok=True)
    cfg,dev,ds,dl,model=load_model_and_loader(a.config,a.manifest,a.checkpoint,batch_size=1); pf=[];gf=[]
    with torch.no_grad():
        for clips,targets in dl:
            pred=model(clips.to(dev)); d=decode_predictions(pred,model.anchors,cfg.get('score_threshold',.05),cfg.get('nms_iou_threshold',.5))[0]; t=targets[0]
            pf.append({'video_id':t['video_id'],'frame_index':t['frame_index'],'boxes':d['boxes'].cpu().numpy(),'labels':d['labels'].cpu().numpy(),'scores':d['scores'].cpu().numpy()})
            gf.append({'video_id':t['video_id'],'frame_index':t['frame_index'],'boxes':t['boxes'].numpy(),'labels':t['labels'].numpy(),'scores':np.ones(len(t['labels']))})
    pt=build_tubes(pf); gt=build_tubes(gf,iou_link=.5,max_gap=1); failures=[]
    for g in gt:
        cand=[p for p in pt if p['video_id']==g['video_id'] and p['label']==g['label']]
        if not cand:
            failures.append({'video_id':g['video_id'],'label':g['label'],'type':'complete_miss','iou':0.0,'gt_start':min(g['frames']),'gt_end':max(g['frames'])}); continue
        vals=[tube_iou(g,p) for p in cand]; j=int(np.argmax(vals)); best=cand[j]; v=vals[j]
        if v<a.strict_iou:
            failures.append({'video_id':g['video_id'],'label':g['label'],'type':classify(g,best),'iou':float(v),'gt_start':min(g['frames']),'gt_end':max(g['frames']),'pred_start':min(best['frames']),'pred_end':max(best['frames'])})
    counts={}
    for f in failures: counts[f['type']]=counts.get(f['type'],0)+1
    json.dump({'counts':counts,'failures':failures},open(out/'temporal_failures.json','w'),indent=2)
    # timeline of first up to six failures
    fig,axes=plt.subplots(min(6,max(1,len(failures))),1,figsize=(10,1.7*min(6,max(1,len(failures)))),squeeze=False)
    for ax,f in zip(axes[:,0],failures[:6]):
        ax.hlines(1,f['gt_start'],f['gt_end'],lw=8,label='GT')
        if 'pred_start' in f: ax.hlines(.4,f['pred_start'],f['pred_end'],lw=8,label='Prediction')
        ax.set_ylim(0,1.4);ax.set_yticks([]);ax.set_title(f"{f['type']}  tube-IoU={f['iou']:.2f}",fontsize=9);ax.legend(loc='upper right',fontsize=7)
    fig.tight_layout();fig.savefig(out/'temporal_failure_timelines.png',dpi=220);plt.close(fig); print(json.dumps(counts,indent=2))
if __name__=='__main__': main()
