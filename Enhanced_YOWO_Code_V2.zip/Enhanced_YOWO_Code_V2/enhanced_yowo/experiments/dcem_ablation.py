#!/usr/bin/env python
import argparse, subprocess, sys, json
from pathlib import Path
import yaml
from enhanced_yowo.experiments.common import best_metric_from_history

VARIANTS=['original_cam','single_ema','single_cam_ema','symmetric_ema','symmetric_cam_ema','asymmetric']

def main():
    p=argparse.ArgumentParser(); p.add_argument('--config',required=True); p.add_argument('--manifest',required=True); p.add_argument('--output',required=True); p.add_argument('--epochs',type=int,default=None)
    a=p.parse_args(); out=Path(a.output); out.mkdir(parents=True,exist_ok=True); results={}
    for var in VARIANTS:
        cfg=yaml.safe_load(open(a.config)); cfg['model']['use_biformer']=False; cfg['model']['use_se']=False; cfg['model']['dcem_variant']=var
        cp=out/f'{var}.yaml'; yaml.safe_dump(cfg,open(cp,'w'),sort_keys=False); od=out/var
        cmd=[sys.executable,'train.py','--config',str(cp),'--manifest',a.manifest,'--frame-split','--output',str(od)]
        if a.epochs: cmd+=['--epochs',str(a.epochs)]
        print(' '.join(cmd)); subprocess.check_call(cmd); results[var]=best_metric_from_history(od/'history.json')
    json.dump(results,open(out/'summary.json','w'),indent=2); print(json.dumps(results,indent=2))
if __name__=='__main__': main()
