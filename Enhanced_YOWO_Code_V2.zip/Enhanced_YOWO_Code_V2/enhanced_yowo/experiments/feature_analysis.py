#!/usr/bin/env python
import argparse, json
from pathlib import Path
import cv2
import numpy as np
import torch
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from sklearn.metrics import silhouette_score

from enhanced_yowo.experiments.common import load_model_and_loader


def roi_avg(feature, boxes):
    # feature C,H,W; boxes normalized xyxy
    c,h,w=feature.shape; vecs=[]
    for b in boxes:
        x1,y1,x2,y2=[float(x) for x in b]
        ix1=max(0,min(w-1,int(x1*w))); ix2=max(ix1+1,min(w,int(np.ceil(x2*w))))
        iy1=max(0,min(h-1,int(y1*h))); iy2=max(iy1+1,min(h,int(np.ceil(y2*h))))
        vecs.append(feature[:,iy1:iy2,ix1:ix2].mean(dim=(1,2)))
    return torch.stack(vecs) if vecs else torch.empty((0,c),device=feature.device)


def inter_intra_ratio(x,y):
    cls=np.unique(y); centers=[]; intra=[]
    for c in cls:
        xc=x[y==c]; cen=xc.mean(0); centers.append(cen); intra.extend(np.linalg.norm(xc-cen,axis=1))
    centers=np.asarray(centers); inter=[]
    for i in range(len(centers)):
        for j in range(i+1,len(centers)): inter.append(np.linalg.norm(centers[i]-centers[j]))
    return float(np.mean(inter)/max(np.mean(intra),1e-9)) if inter and intra else 0.0


def parse_spec(s):
    # name|config|checkpoint
    a=s.split('|');
    if len(a)!=3: raise ValueError('Model spec must be name|config|checkpoint')
    return a


def main():
    p=argparse.ArgumentParser(); p.add_argument('--manifest',required=True); p.add_argument('--model',action='append',required=True,help='name|config|checkpoint; repeat 4x'); p.add_argument('--output',required=True); p.add_argument('--max-instances',type=int,default=3000); p.add_argument('--activation-examples',type=int,default=4)
    a=p.parse_args(); out=Path(a.output); out.mkdir(parents=True,exist_ok=True); summaries={}; embeddings=[]
    for spec in a.model:
        name,cfgp,ckpt=parse_spec(spec); cfg,device,ds,dl,model=load_model_and_loader(cfgp,a.manifest,ckpt,batch_size=1)
        feats=[]; labels=[]; activation_saved=0
        with torch.no_grad():
            for clips,targets in dl:
                clips=clips.to(device); pred,fused=model(clips,return_features=True)
                for bi,t in enumerate(targets):
                    v=roi_avg(fused[bi],t['boxes'].to(device))
                    if len(v): feats.append(v.cpu().numpy()); labels.extend(t['labels'].numpy().tolist())
                    if activation_saved<a.activation_examples:
                        heat=fused[bi].abs().mean(0).cpu().numpy(); heat=cv2.resize(heat,(cfg['image_size'],cfg['image_size'])); heat=(heat-heat.min())/(heat.max()-heat.min()+1e-9)
                        img=cv2.imread(t['frame_path']); img=cv2.resize(img,(cfg['image_size'],cfg['image_size']))
                        cmap=cv2.applyColorMap((heat*255).astype(np.uint8),cv2.COLORMAP_JET); overlay=cv2.addWeighted(img,0.55,cmap,0.45,0)
                        cv2.imwrite(str(out/f'{name}_activation_{activation_saved+1}.jpg'),overlay); activation_saved+=1
                    if sum(len(x) for x in feats)>=a.max_instances: break
        x=np.concatenate(feats,axis=0)[:a.max_instances]; y=np.asarray(labels)[:len(x)]
        if len(x)>a.max_instances: x=x[:a.max_instances]; y=y[:a.max_instances]
        sil=float(silhouette_score(x,y)) if len(np.unique(y))>1 and len(x)>len(np.unique(y)) else 0.0
        ratio=inter_intra_ratio(x,y)
        n=min(len(x),1500); z=TSNE(n_components=2,perplexity=min(30,max(5,n//20)),init='pca',learning_rate='auto',random_state=42).fit_transform(x[:n])
        embeddings.append((name,z,y[:n])); summaries[name]={'silhouette_score':sil,'inter_intra_ratio':ratio,'n_instances':int(len(x))}
    fig,axes=plt.subplots(1,len(embeddings),figsize=(5*len(embeddings),4),squeeze=False)
    for ax,(name,z,y) in zip(axes[0],embeddings):
        for c in np.unique(y): ax.scatter(z[y==c,0],z[y==c,1],s=7,alpha=.6,label=str(c))
        ax.set_title(name); ax.set_xticks([]); ax.set_yticks([])
    if embeddings: axes[0,-1].legend(fontsize=6,bbox_to_anchor=(1.02,1),loc='upper left')
    fig.tight_layout(); fig.savefig(out/'tsne_comparison.png',dpi=220,bbox_inches='tight'); plt.close(fig)
    json.dump(summaries,open(out/'feature_metrics.json','w'),indent=2); print(json.dumps(summaries,indent=2))
if __name__=='__main__': main()
