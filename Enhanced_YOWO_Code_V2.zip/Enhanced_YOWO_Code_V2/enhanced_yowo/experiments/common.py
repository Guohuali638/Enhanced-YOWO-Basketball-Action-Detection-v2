import json
from pathlib import Path
import torch
from torch.utils.data import DataLoader

from enhanced_yowo.data import VideoActionDataset, detection_collate
from enhanced_yowo.models import build_model
from enhanced_yowo.utils.common import load_config, get_device


def load_model_and_loader(config_path, manifest, checkpoint, sources=None, batch_size=None):
    cfg = load_config(config_path)
    device = get_device(cfg.get('device','cuda'))
    ds = VideoActionDataset(manifest, cfg['image_size'], cfg['clip_len'], cfg.get('frame_stride',1), False, allowed_sources=sources)
    dl = DataLoader(ds, batch_size=batch_size or cfg['batch_size'], shuffle=False, num_workers=cfg['num_workers'], pin_memory=True, collate_fn=detection_collate)
    model = build_model(cfg).to(device)
    ck = torch.load(checkpoint, map_location='cpu')
    model.load_state_dict(ck['model'])
    model.eval()
    return cfg, device, ds, dl, model


def best_metric_from_history(path):
    hist = json.load(open(path,'r'))
    return max((r['frame_map'] for r in hist), default=0.0)
