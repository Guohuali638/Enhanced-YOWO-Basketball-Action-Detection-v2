#!/usr/bin/env python
import argparse, json
from pathlib import Path
import cv2
import numpy as np
import torch
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix

from enhanced_yowo.experiments.common import load_model_and_loader
from enhanced_yowo.utils.decode import decode_predictions
from enhanced_yowo.utils.boxes import box_iou
from enhanced_yowo.utils.visual import draw_boxes


def main():
    p=argparse.ArgumentParser(); p.add_argument('--config',required=True); p.add_argument('--manifest',required=True); p.add_argument('--checkpoint',required=True); p.add_argument('--output',required=True); p.add_argument('--max-examples',type=int,default=12)
    a=p.parse_args(); out=Path(a.output); out.mkdir(parents=True,exist_ok=True)
    cfg,device,ds,dl,model=load_model_and_loader(a.config,a.manifest,a.checkpoint,batch_size=1); nc=cfg['num_classes']; names=cfg.get('class_names') or [str(i) for i in range(nc)]
    ytrue=[]; ypred=[]; tp=np.zeros(nc,int); fp=np.zeros(nc,int); fn=np.zeros(nc,int); saved=0
    with torch.no_grad():
        for clips,targets in dl:
            clips=clips.to(device); pred=model(clips); det=decode_predictions(pred,model.anchors,cfg.get('score_threshold',.05),cfg.get('nms_iou_threshold',.5))[0]
            t=targets[0]; gb=t['boxes']; gl=t['labels']; pb=det['boxes'].cpu(); pl=det['labels'].cpu(); ps=det['scores'].cpu(); used=set()
            if len(gb) and len(pb): ious=box_iou(gb,pb)
            else: ious=torch.zeros((len(gb),len(pb)))
            for gi in range(len(gb)):
                if len(pb)==0: fn[int(gl[gi])]+=1; continue
                vals=ious[gi].clone()
                for j in used: vals[j]=-1
                j=int(vals.argmax())
                if vals[j]>=cfg.get('frame_map_iou',.5):
                    used.add(j); gt=int(gl[gi]); pr=int(pl[j]); ytrue.append(gt); ypred.append(pr)
                    if gt==pr: tp[gt]+=1
                    else: fn[gt]+=1; fp[pr]+=1
                else: fn[int(gl[gi])]+=1
            for j in range(len(pb)):
                if j not in used: fp[int(pl[j])]+=1
            difficult=set(np.argsort(fn)[-3:].tolist())
            has_failure=any(int(g) in difficult for g in gl.tolist()) and (len(used)<len(gb) or any(ytrue[k]!=ypred[k] for k in range(max(0,len(ytrue)-len(gb)),len(ytrue))))
            if has_failure and saved<a.max_examples:
                img=cv2.imread(t['frame_path']); gtimg=draw_boxes(img,gb.numpy(),gl.numpy(),None,names); predimg=draw_boxes(img,pb.numpy(),pl.numpy(),ps.numpy(),names); combo=np.concatenate([gtimg,predimg],axis=1); cv2.imwrite(str(out/f'failure_{saved+1:02d}.jpg'),combo); saved+=1
    cm=confusion_matrix(ytrue,ypred,labels=list(range(nc)),normalize='true') if ytrue else np.zeros((nc,nc))
    fig,ax=plt.subplots(figsize=(9,8)); im=ax.imshow(cm,vmin=0,vmax=1); ax.set_xticks(range(nc));ax.set_xticklabels(names,rotation=45,ha='right');ax.set_yticks(range(nc));ax.set_yticklabels(names); ax.set_xlabel('Predicted');ax.set_ylabel('Ground truth');fig.colorbar(im,ax=ax);fig.tight_layout();fig.savefig(out/'confusion_matrix_normalized.png',dpi=220);plt.close(fig)
    rows=[]
    for c in range(nc):
        prec=tp[c]/max(tp[c]+fp[c],1); rec=tp[c]/max(tp[c]+fn[c],1); rows.append({'class':names[c],'TP':int(tp[c]),'FP':int(fp[c]),'FN':int(fn[c]),'precision':float(prec),'recall':float(rec)})
    json.dump({'rows':rows,'confusion_matrix':cm.tolist()},open(out/'error_statistics.json','w'),indent=2); print(json.dumps(rows,indent=2))
if __name__=='__main__': main()
