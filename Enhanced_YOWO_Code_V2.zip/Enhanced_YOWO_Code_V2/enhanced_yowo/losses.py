from typing import Dict, List
import torch
import torch.nn as nn
import torch.nn.functional as F

from .utils.boxes import xyxy_to_cxcywh, wh_iou


class FocalBCEWithLogits(nn.Module):
    def __init__(self, gamma=2.0, alpha=0.25, reduction='mean'):
        super().__init__()
        self.gamma = gamma
        self.alpha = alpha
        self.reduction = reduction

    def forward(self, logits, targets):
        bce = F.binary_cross_entropy_with_logits(logits, targets, reduction='none')
        prob = torch.sigmoid(logits)
        p_t = prob * targets + (1 - prob) * (1 - targets)
        alpha_t = self.alpha * targets + (1 - self.alpha) * (1 - targets)
        loss = alpha_t * (1 - p_t).pow(self.gamma) * bce
        if self.reduction == 'sum': return loss.sum()
        if self.reduction == 'none': return loss
        return loss.mean()


class YOWOLoss(nn.Module):
    def __init__(self, anchors, num_classes, cfg: Dict):
        super().__init__()
        self.register_buffer('anchors', torch.tensor(anchors, dtype=torch.float32))
        self.num_classes = num_classes
        self.box_weight = cfg.get('box_weight', 5.0)
        self.obj_weight = cfg.get('obj_weight', 1.0)
        self.cls_weight = cfg.get('cls_weight', 1.0)
        gamma = cfg.get('focal_gamma', 2.0)
        alpha = cfg.get('focal_alpha', 0.25)
        self.focal = FocalBCEWithLogits(gamma, alpha, reduction='none')

    def forward(self, pred: torch.Tensor, targets: List[Dict]):
        # pred: B,A,H,W,5+C
        device = pred.device
        bsz, na, gh, gw, _ = pred.shape
        obj_t = torch.zeros((bsz, na, gh, gw), device=device)
        cls_t = torch.zeros((bsz, na, gh, gw, self.num_classes), device=device)
        box_t = torch.zeros((bsz, na, gh, gw, 4), device=device)
        pos = torch.zeros((bsz, na, gh, gw), dtype=torch.bool, device=device)

        anchors = self.anchors.to(device)
        for b, t in enumerate(targets):
            boxes = t['boxes'].to(device)
            labels = t['labels'].to(device)
            if boxes.numel() == 0:
                continue
            cxywh = xyxy_to_cxcywh(boxes)
            for box, lab in zip(cxywh, labels):
                cx, cy, bw, bh = box
                gx = torch.clamp(cx * gw, 0, gw - 1e-4)
                gy = torch.clamp(cy * gh, 0, gh - 1e-4)
                gi, gj = int(gx), int(gy)
                a = int(wh_iou(box[None, 2:4], anchors).argmax())
                obj_t[b, a, gj, gi] = 1.0
                cls_t[b, a, gj, gi, int(lab)] = 1.0
                box_t[b, a, gj, gi, 0] = gx - gi
                box_t[b, a, gj, gi, 1] = gy - gj
                box_t[b, a, gj, gi, 2] = torch.log((bw / anchors[a, 0]).clamp(min=1e-6))
                box_t[b, a, gj, gi, 3] = torch.log((bh / anchors[a, 1]).clamp(min=1e-6))
                pos[b, a, gj, gi] = True

        pbox = pred[..., :4]
        pobj = pred[..., 4]
        pcls = pred[..., 5:]
        obj_loss = self.focal(pobj, obj_t).mean()
        if pos.any():
            pxy = torch.sigmoid(pbox[..., :2][pos])
            pwh = pbox[..., 2:4][pos]
            box_pred = torch.cat([pxy, pwh], dim=-1)
            box_loss = F.smooth_l1_loss(box_pred, box_t[pos], reduction='mean')
            cls_loss = self.focal(pcls[pos], cls_t[pos]).mean()
        else:
            box_loss = pred.sum() * 0.0
            cls_loss = pred.sum() * 0.0
        total = self.box_weight * box_loss + self.obj_weight * obj_loss + self.cls_weight * cls_loss
        return total, {'box': float(box_loss.detach()), 'obj': float(obj_loss.detach()), 'cls': float(cls_loss.detach())}
