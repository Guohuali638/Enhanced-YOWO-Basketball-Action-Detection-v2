import json
import os
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np
import torch
from torch.utils.data import Dataset


class VideoActionDataset(Dataset):
    """
    Unified dataset for the MultiSports-derived basketball subset and UCF101-24.

    Manifest schema is documented in data_manifest_example.json. Bounding boxes may
    be absolute pixels or normalized coordinates. Labels must be zero-based.
    A sample is created for every annotated keyframe.
    """
    def __init__(self, manifest_path: str, image_size=480, clip_len=16, frame_stride=1,
                 training=False, hflip=0.0, vflip=0.0, color_jitter=0.0,
                 allowed_sources: Optional[List[str]] = None,
                 allowed_videos: Optional[List[str]] = None,
                 allowed_keys: Optional[set] = None):
        super().__init__()
        with open(manifest_path, "r", encoding="utf-8") as f:
            self.manifest = json.load(f)
        self.image_size = image_size
        self.clip_len = clip_len
        self.frame_stride = frame_stride
        self.training = training
        self.hflip = hflip
        self.vflip = vflip
        self.color_jitter = color_jitter
        allowed_sources = set(allowed_sources) if allowed_sources else None
        allowed_videos = set(allowed_videos) if allowed_videos else None
        self.videos = {}
        self.samples = []
        for v in self.manifest["videos"]:
            if allowed_sources is not None and v.get("source_id", v["video_id"]) not in allowed_sources:
                continue
            if allowed_videos is not None and v["video_id"] not in allowed_videos:
                continue
            ann_map = {int(a["frame_index"]): a for a in v.get("annotations", [])}
            vv = dict(v)
            vv["ann_map"] = ann_map
            self.videos[v["video_id"]] = vv
            for fi, ann in ann_map.items():
                key = (v["video_id"], int(fi))
                if allowed_keys is None or key in allowed_keys:
                    self.samples.append(key)
        self.samples.sort()

    def __len__(self):
        return len(self.samples)

    def _frame_path(self, v: Dict, idx: int) -> str:
        if "frames" in v:
            # explicit mapping/list
            frames = v["frames"]
            if isinstance(frames, dict):
                return frames[str(idx)]
            base = int(v.get("first_frame", 0))
            return frames[idx - base]
        pat = v.get("frame_pattern", "%06d.jpg")
        return os.path.join(v["frames_dir"], pat % idx)

    def _clip_indices(self, v: Dict, key_idx: int):
        first = int(v.get("first_frame", 1))
        last = int(v.get("last_frame", key_idx))
        center = self.clip_len // 2
        inds = []
        for t in range(self.clip_len):
            idx = key_idx + (t - center) * self.frame_stride
            inds.append(min(last, max(first, idx)))
        return inds

    def _read_frame(self, path: str):
        im = cv2.imread(path)
        if im is None:
            raise FileNotFoundError(path)
        im = cv2.cvtColor(im, cv2.COLOR_BGR2RGB)
        return im

    def _normalize_boxes(self, boxes, v):
        boxes = np.asarray(boxes, dtype=np.float32).reshape(-1, 4)
        if len(boxes) == 0:
            return boxes
        if boxes.max() > 1.5:
            w = float(v.get("width", 1))
            h = float(v.get("height", 1))
            boxes[:, [0, 2]] /= w
            boxes[:, [1, 3]] /= h
        return np.clip(boxes, 0.0, 1.0)

    def _augment(self, frames: List[np.ndarray], boxes: np.ndarray):
        if self.training and np.random.rand() < self.hflip:
            frames = [np.ascontiguousarray(f[:, ::-1]) for f in frames]
            if len(boxes):
                x1 = 1.0 - boxes[:, 2].copy()
                x2 = 1.0 - boxes[:, 0].copy()
                boxes[:, 0], boxes[:, 2] = x1, x2
        if self.training and np.random.rand() < self.vflip:
            frames = [np.ascontiguousarray(f[::-1, :]) for f in frames]
            if len(boxes):
                y1 = 1.0 - boxes[:, 3].copy()
                y2 = 1.0 - boxes[:, 1].copy()
                boxes[:, 1], boxes[:, 3] = y1, y2
        if self.training and self.color_jitter > 0:
            gain = 1.0 + np.random.uniform(-self.color_jitter, self.color_jitter)
            bias = np.random.uniform(-20, 20) * self.color_jitter
            frames = [np.clip(f.astype(np.float32)*gain+bias, 0, 255).astype(np.uint8) for f in frames]
        return frames, boxes

    def __getitem__(self, idx):
        video_id, key_idx = self.samples[idx]
        v = self.videos[video_id]
        ann = v["ann_map"][key_idx]
        inds = self._clip_indices(v, key_idx)
        frames = [self._read_frame(self._frame_path(v, i)) for i in inds]
        boxes = self._normalize_boxes(ann.get("boxes", []), v)
        labels = np.asarray(ann.get("labels", []), dtype=np.int64)
        tracks = np.asarray(ann.get("track_ids", [-1] * len(labels)), dtype=np.int64)
        if len(labels) and labels.min() < 0:
            raise ValueError("Labels must be zero-based non-negative integers")
        frames, boxes = self._augment(frames, boxes)
        resized = [cv2.resize(f, (self.image_size, self.image_size), interpolation=cv2.INTER_LINEAR) for f in frames]
        arr = np.stack(resized).astype(np.float32) / 255.0
        # ImageNet-style normalization is intentionally not forced; paper training can be reproduced with raw [0,1].
        clip = torch.from_numpy(arr).permute(0,3,1,2).contiguous()
        target = {
            "boxes": torch.tensor(boxes, dtype=torch.float32),
            "labels": torch.tensor(labels, dtype=torch.long),
            "track_ids": torch.tensor(tracks, dtype=torch.long),
            "video_id": video_id,
            "source_id": v.get("source_id", video_id),
            "frame_index": int(key_idx),
            "frame_path": self._frame_path(v, key_idx),
            "orig_size": (int(v.get("height", frames[0].shape[0])), int(v.get("width", frames[0].shape[1]))),
        }
        return clip, target


def detection_collate(batch):
    clips = torch.stack([b[0] for b in batch], dim=0)
    targets = [b[1] for b in batch]
    return clips, targets


def load_manifest(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_manifest(m, path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(m, f, ensure_ascii=False, indent=2)


def manifest_sources(manifest_path):
    m = load_manifest(manifest_path)
    return sorted(set(v.get("source_id", v["video_id"]) for v in m["videos"]))


def split_manifest_by_sources(manifest_path, train_sources, val_sources, out_train, out_val):
    m = load_manifest(manifest_path)
    base = {k: v for k, v in m.items() if k != "videos"}
    train = dict(base); val = dict(base)
    train["videos"] = [v for v in m["videos"] if v.get("source_id", v["video_id"]) in set(train_sources)]
    val["videos"] = [v for v in m["videos"] if v.get("source_id", v["video_id"]) in set(val_sources)]
    save_manifest(train, out_train); save_manifest(val, out_val)


def random_frame_split_keys(manifest_path: str, train_ratio=0.8, seed=42):
    rng = np.random.RandomState(seed)
    m = load_manifest(manifest_path)
    keys = []
    for v in m["videos"]:
        for a in v.get("annotations", []):
            keys.append((v["video_id"], int(a["frame_index"])))
    rng.shuffle(keys)
    n = int(len(keys)*train_ratio)
    return set(keys[:n]), set(keys[n:])
