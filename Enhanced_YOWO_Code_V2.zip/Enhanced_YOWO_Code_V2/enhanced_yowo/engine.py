import time
from pathlib import Path
from typing import Dict

import numpy as np
import torch
from torch.cuda.amp import autocast, GradScaler
from tqdm import tqdm

from .losses import YOWOLoss
from .utils.decode import decode_predictions
from .utils.metrics import frame_map


def train_one_epoch(model, loader, optimizer, criterion, device, scaler=None, amp=True):
    model.train()
    losses = []
    stats = {'box': [], 'obj': [], 'cls': []}
    pbar = tqdm(loader, desc='train', leave=False)
    for clips, targets in pbar:
        clips = clips.to(device, non_blocking=True)
        optimizer.zero_grad(set_to_none=True)
        with autocast(enabled=amp and device.type == 'cuda'):
            pred = model(clips)
            loss, parts = criterion(pred, targets)
        if scaler is not None and amp and device.type == 'cuda':
            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
        else:
            loss.backward(); optimizer.step()
        losses.append(float(loss.detach()))
        for k in stats: stats[k].append(parts[k])
        pbar.set_postfix(loss=f'{losses[-1]:.4f}')
    out = {'loss': float(np.mean(losses) if losses else 0.0)}
    out.update({k: float(np.mean(v) if v else 0.0) for k, v in stats.items()})
    return out


@torch.no_grad()
def evaluate_frame(model, loader, cfg, device):
    model.eval()
    records = []
    anchors = model.anchors
    for clips, targets in tqdm(loader, desc='eval', leave=False):
        clips = clips.to(device, non_blocking=True)
        pred = model(clips)
        dets = decode_predictions(pred, anchors, cfg.get('score_threshold',0.05), cfg.get('nms_iou_threshold',0.5))
        for d, t in zip(dets, targets):
            records.append({
                'video_id': t['video_id'], 'frame_index': t['frame_index'],
                'gt_boxes': t['boxes'].numpy(), 'gt_labels': t['labels'].numpy(), 'gt_track_ids': t.get('track_ids', torch.full((len(t['labels']),), -1, dtype=torch.long)).numpy(),
                'pred_boxes': d['boxes'].cpu().numpy(), 'pred_scores': d['scores'].cpu().numpy(), 'pred_labels': d['labels'].cpu().numpy(),
            })
    m, pc = frame_map(records, cfg['num_classes'], cfg.get('frame_map_iou',0.5))
    return m, pc, records
