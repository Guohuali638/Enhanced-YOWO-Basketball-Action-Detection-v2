from pathlib import Path
from typing import List
import cv2
import numpy as np


def draw_boxes(image: np.ndarray, boxes, labels, scores=None, class_names: List[str] = None):
    out = image.copy()
    h, w = out.shape[:2]
    for i, box in enumerate(boxes):
        x1, y1, x2, y2 = box
        if max(box) <= 1.5:
            x1, x2 = x1*w, x2*w
            y1, y2 = y1*h, y2*h
        p1, p2 = (int(x1), int(y1)), (int(x2), int(y2))
        cv2.rectangle(out, p1, p2, (0,255,0), 2)
        name = str(int(labels[i]))
        if class_names and int(labels[i]) < len(class_names):
            name = class_names[int(labels[i])]
        if scores is not None:
            name += f" {float(scores[i]):.2f}"
        cv2.putText(out, name, (p1[0], max(15, p1[1]-5)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,255,0), 1, cv2.LINE_AA)
    return out


def save_image(path, image):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    cv2.imwrite(str(path), image)
