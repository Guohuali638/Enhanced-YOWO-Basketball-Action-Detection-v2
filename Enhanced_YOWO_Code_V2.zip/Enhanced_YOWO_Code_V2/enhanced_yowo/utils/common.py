import json
import os
import random
from pathlib import Path
from typing import Any, Dict

import numpy as np
import torch
import yaml


def load_config(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def save_json(obj: Any, path: str) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def set_seed(seed: int, deterministic: bool = True) -> None:
    """Set RNG seeds and optionally request deterministic execution.

    Determinism can reduce speed and some CUDA operations may only be
    deterministically available on specific PyTorch/CUDA versions. The run
    metadata records the exact software stack so that this setting is auditable.
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = bool(deterministic)
    torch.backends.cudnn.benchmark = not bool(deterministic)
    if hasattr(torch, "use_deterministic_algorithms"):
        torch.use_deterministic_algorithms(bool(deterministic), warn_only=True)


def get_device(name: str = "cuda") -> torch.device:
    if name.startswith("cuda") and torch.cuda.is_available():
        return torch.device(name)
    return torch.device("cpu")


def ensure_dir(path: str) -> str:
    os.makedirs(path, exist_ok=True)
    return path


def model_num_parameters(model: torch.nn.Module) -> int:
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def strip_module_prefix(state):
    out = {}
    for k, v in state.items():
        out[k[7:] if k.startswith("module.") else k] = v
    return out


def load_partial_weights(module: torch.nn.Module, path: str, prefix: str = "") -> Dict[str, Any]:
    ckpt = torch.load(path, map_location="cpu")
    state = ckpt.get("model", ckpt.get("state_dict", ckpt))
    state = strip_module_prefix(state)
    if prefix:
        state = {k[len(prefix):]: v for k, v in state.items() if k.startswith(prefix)}
    own = module.state_dict()
    matched = {k: v for k, v in state.items() if k in own and own[k].shape == v.shape}
    missing, unexpected = module.load_state_dict(matched, strict=False)
    return {
        "loaded": len(matched),
        "missing": len(missing),
        "unexpected": len(unexpected),
        "source": path,
    }
