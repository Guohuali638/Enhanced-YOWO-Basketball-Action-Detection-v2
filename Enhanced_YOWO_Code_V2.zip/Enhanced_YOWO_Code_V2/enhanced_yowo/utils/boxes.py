from typing import List
import torch


def xyxy_to_cxcywh(boxes: torch.Tensor) -> torch.Tensor:
    x1, y1, x2, y2 = boxes.unbind(-1)
    return torch.stack(((x1+x2)/2, (y1+y2)/2, x2-x1, y2-y1), dim=-1)


def cxcywh_to_xyxy(boxes: torch.Tensor) -> torch.Tensor:
    cx, cy, w, h = boxes.unbind(-1)
    return torch.stack((cx-w/2, cy-h/2, cx+w/2, cy+h/2), dim=-1)


def box_iou(boxes1: torch.Tensor, boxes2: torch.Tensor) -> torch.Tensor:
    if boxes1.numel() == 0 or boxes2.numel() == 0:
        return torch.zeros((boxes1.shape[0], boxes2.shape[0]), device=boxes1.device)
    area1 = ((boxes1[:, 2]-boxes1[:, 0]).clamp(min=0) * (boxes1[:, 3]-boxes1[:, 1]).clamp(min=0))
    area2 = ((boxes2[:, 2]-boxes2[:, 0]).clamp(min=0) * (boxes2[:, 3]-boxes2[:, 1]).clamp(min=0))
    lt = torch.maximum(boxes1[:, None, :2], boxes2[None, :, :2])
    rb = torch.minimum(boxes1[:, None, 2:], boxes2[None, :, 2:])
    wh = (rb-lt).clamp(min=0)
    inter = wh[..., 0] * wh[..., 1]
    return inter / (area1[:, None] + area2[None, :] - inter + 1e-9)


def wh_iou(wh1: torch.Tensor, wh2: torch.Tensor) -> torch.Tensor:
    wh1 = wh1[:, None, :]
    wh2 = wh2[None, :, :]
    inter = torch.minimum(wh1, wh2).prod(-1)
    union = wh1.prod(-1) + wh2.prod(-1) - inter
    return inter / (union + 1e-9)


def nms(boxes: torch.Tensor, scores: torch.Tensor, iou_thr: float = 0.5) -> torch.Tensor:
    if boxes.numel() == 0:
        return torch.empty((0,), dtype=torch.long, device=boxes.device)
    order = scores.argsort(descending=True)
    keep: List[int] = []
    while order.numel() > 0:
        i = int(order[0])
        keep.append(i)
        if order.numel() == 1:
            break
        ious = box_iou(boxes[i:i+1], boxes[order[1:]])[0]
        order = order[1:][ious <= iou_thr]
    return torch.tensor(keep, dtype=torch.long, device=boxes.device)


def clip_boxes(boxes: torch.Tensor) -> torch.Tensor:
    return boxes.clamp(0.0, 1.0)
