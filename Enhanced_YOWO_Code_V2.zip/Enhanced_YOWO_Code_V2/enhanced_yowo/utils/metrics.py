from collections import defaultdict
from typing import Dict, List, Tuple
import numpy as np
import torch

from .boxes import box_iou


def _ap_from_pr(rec, prec):
    mrec = np.concatenate(([0.0], rec, [1.0]))
    mpre = np.concatenate(([0.0], prec, [0.0]))
    for i in range(mpre.size - 1, 0, -1):
        mpre[i - 1] = max(mpre[i - 1], mpre[i])
    idx = np.where(mrec[1:] != mrec[:-1])[0]
    return np.sum((mrec[idx + 1] - mrec[idx]) * mpre[idx + 1])


def frame_map(records: List[Dict], num_classes: int, iou_thr=0.5):
    aps = []
    per_class = {}
    for c in range(num_classes):
        gt_by_img = {}
        npos = 0
        preds = []
        for ri, r in enumerate(records):
            gt_mask = r['gt_labels'] == c
            gt_boxes = r['gt_boxes'][gt_mask]
            gt_by_img[ri] = {'boxes': gt_boxes, 'used': np.zeros(len(gt_boxes), dtype=bool)}
            npos += len(gt_boxes)
            pm = r['pred_labels'] == c
            for box, score in zip(r['pred_boxes'][pm], r['pred_scores'][pm]):
                preds.append((float(score), ri, box))
        preds.sort(key=lambda x: x[0], reverse=True)
        tp = np.zeros(len(preds)); fp = np.zeros(len(preds))
        for i, (_, ri, box) in enumerate(preds):
            gt = gt_by_img[ri]
            if len(gt['boxes']) == 0:
                fp[i] = 1; continue
            ious = box_iou(torch.tensor(box[None], dtype=torch.float32), torch.tensor(gt['boxes'], dtype=torch.float32))[0].numpy()
            j = int(ious.argmax())
            if ious[j] >= iou_thr and not gt['used'][j]:
                tp[i] = 1; gt['used'][j] = True
            else:
                fp[i] = 1
        if npos == 0:
            ap = np.nan
        else:
            tp_c = np.cumsum(tp); fp_c = np.cumsum(fp)
            rec = tp_c / max(npos, 1)
            prec = tp_c / np.maximum(tp_c + fp_c, 1e-12)
            ap = _ap_from_pr(rec, prec)
        per_class[c] = ap
        if not np.isnan(ap): aps.append(ap)
    return float(np.mean(aps) if aps else 0.0), per_class


def build_tubes(frame_records: List[Dict], iou_link=0.3, max_gap=2, use_track_ids=True):
    """Build class-specific tubes.

    If non-negative ``track_ids`` are supplied (recommended for ground truth),
    they are used directly. Detections without track IDs are linked greedily by
    class, temporal gap and spatial IoU. The exact parameters must be reported
    with any Video-mAP numbers.
    """
    explicit = defaultdict(list)
    grouped = defaultdict(list)
    for r in frame_records:
        vid, fi = r['video_id'], int(r['frame_index'])
        tids = r.get('track_ids', [-1] * len(r['labels']))
        for box, label, score, tid in zip(r['boxes'], r['labels'], r['scores'], tids):
            box = np.asarray(box); label = int(label); tid = int(tid)
            if use_track_ids and tid >= 0:
                explicit[(vid, label, tid)].append((fi, box, float(score)))
            else:
                grouped[(vid, label)].append((fi, box, float(score)))
    tubes = []
    for (vid, label, tid), dets in explicit.items():
        dets.sort(key=lambda x: x[0])
        t={'video_id':vid,'label':label,'track_id':tid,'frames':[x[0] for x in dets],
           'boxes':[x[1] for x in dets],'scores':[x[2] for x in dets]}
        t['score']=float(np.mean(t['scores'])) if t['scores'] else 0.0
        tubes.append(t)
    for (vid, label), dets in grouped.items():
        dets.sort(key=lambda x: x[0])
        active = []
        for fi, box, score in dets:
            best, best_iou = None, -1
            for ti, t in enumerate(active):
                if fi - t['frames'][-1] > max_gap:
                    continue
                ov = float(box_iou(torch.tensor(box[None], dtype=torch.float32), torch.tensor(t['boxes'][-1][None], dtype=torch.float32))[0,0])
                if ov > best_iou:
                    best_iou, best = ov, ti
            if best is not None and best_iou >= iou_link:
                active[best]['frames'].append(fi); active[best]['boxes'].append(box); active[best]['scores'].append(score)
            else:
                active.append({'video_id': vid, 'label': label, 'frames': [fi], 'boxes': [box], 'scores': [score]})
        for t in active:
            t['score'] = float(np.mean(t['scores']))
            tubes.append(t)
    return tubes


def tube_iou(t1, t2):
    f1 = {f: b for f, b in zip(t1['frames'], t1['boxes'])}
    f2 = {f: b for f, b in zip(t2['frames'], t2['boxes'])}
    s1, s2 = set(f1), set(f2)
    inter_frames = sorted(s1 & s2)
    union_frames = s1 | s2
    if not inter_frames or not union_frames:
        return 0.0
    temporal_iou = len(inter_frames) / len(union_frames)
    spatial = []
    for f in inter_frames:
        iou = box_iou(torch.tensor(f1[f][None], dtype=torch.float32), torch.tensor(f2[f][None], dtype=torch.float32))[0,0]
        spatial.append(float(iou))
    return temporal_iou * float(np.mean(spatial))


def video_map(pred_tubes, gt_tubes, num_classes, iou_thr=0.5):
    aps = []
    for c in range(num_classes):
        gt = [t for t in gt_tubes if t['label'] == c]
        pred = sorted([t for t in pred_tubes if t['label'] == c], key=lambda x: x['score'], reverse=True)
        used = np.zeros(len(gt), dtype=bool)
        tp = np.zeros(len(pred)); fp = np.zeros(len(pred))
        for i, p in enumerate(pred):
            cand = [j for j, g in enumerate(gt) if g['video_id'] == p['video_id'] and not used[j]]
            if not cand:
                fp[i] = 1; continue
            vals = [tube_iou(p, gt[j]) for j in cand]
            k = int(np.argmax(vals)); j = cand[k]
            if vals[k] >= iou_thr:
                tp[i] = 1; used[j] = True
            else:
                fp[i] = 1
        if len(gt) == 0: continue
        tpc = np.cumsum(tp); fpc = np.cumsum(fp)
        rec = tpc / len(gt); prec = tpc / np.maximum(tpc+fpc, 1e-12)
        aps.append(_ap_from_pr(rec, prec))
    return float(np.mean(aps) if aps else 0.0)
