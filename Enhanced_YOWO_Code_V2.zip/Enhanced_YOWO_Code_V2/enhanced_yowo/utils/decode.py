from typing import Dict, List
import torch

from .boxes import cxcywh_to_xyxy, clip_boxes, nms


def decode_predictions(pred: torch.Tensor, anchors: torch.Tensor, score_thr=0.05, nms_iou=0.5,
                       max_det=300) -> List[Dict[str, torch.Tensor]]:
    # pred B,A,H,W,5+C
    bsz, na, gh, gw, nc5 = pred.shape
    nc = nc5 - 5
    device = pred.device
    yy, xx = torch.meshgrid(torch.arange(gh, device=device), torch.arange(gw, device=device), indexing='ij')
    grid = torch.stack([xx, yy], dim=-1).float()[None, None]  # 1,1,H,W,2
    xy = (torch.sigmoid(pred[..., :2]) + grid) / torch.tensor([gw, gh], device=device)
    wh = torch.exp(pred[..., 2:4].clamp(max=5.0)) * anchors.to(device)[None, :, None, None, :]
    boxes = clip_boxes(cxcywh_to_xyxy(torch.cat([xy, wh], dim=-1)))
    obj = torch.sigmoid(pred[..., 4])
    cls = torch.sigmoid(pred[..., 5:])
    outputs = []
    for b in range(bsz):
        all_b, all_s, all_l = [], [], []
        for c in range(nc):
            scores = obj[b] * cls[b, ..., c]
            mask = scores > score_thr
            if not mask.any():
                continue
            bs = boxes[b][mask]
            ss = scores[mask]
            keep = nms(bs, ss, nms_iou)[:max_det]
            all_b.append(bs[keep]); all_s.append(ss[keep]); all_l.append(torch.full((len(keep),), c, dtype=torch.long, device=device))
        if all_b:
            bxs, scs, lbs = torch.cat(all_b), torch.cat(all_s), torch.cat(all_l)
            order = scs.argsort(descending=True)[:max_det]
            outputs.append({'boxes': bxs[order], 'scores': scs[order], 'labels': lbs[order]})
        else:
            outputs.append({'boxes': torch.empty((0,4), device=device), 'scores': torch.empty((0,), device=device), 'labels': torch.empty((0,), dtype=torch.long, device=device)})
    return outputs
