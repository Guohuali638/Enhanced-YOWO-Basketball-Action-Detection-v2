from typing import Sequence
import torch
import torch.nn as nn
import torch.nn.functional as F

from .attention import BiFormerBlock, SE3D


def conv_bn_lrelu(cin, cout, k=3, s=1):
    p = k // 2
    return nn.Sequential(
        nn.Conv2d(cin, cout, k, s, p, bias=False),
        nn.BatchNorm2d(cout),
        nn.LeakyReLU(0.1, inplace=True),
    )


class DarknetSpatialBranch(nn.Module):
    """Darknet-like spatial branch ending at 1/32 resolution."""
    def __init__(self, out_dim=512, use_biformer=True, biformer_heads=8,
                 biformer_topk=4, biformer_regions=3, biformer_depth=2):
        super().__init__()
        self.stem = nn.Sequential(
            conv_bn_lrelu(3, 32), nn.MaxPool2d(2,2),
            conv_bn_lrelu(32, 64), nn.MaxPool2d(2,2),
            conv_bn_lrelu(64, 128), conv_bn_lrelu(128, 64, 1), conv_bn_lrelu(64, 128), nn.MaxPool2d(2,2),
            conv_bn_lrelu(128, 256), conv_bn_lrelu(256, 128, 1), conv_bn_lrelu(128, 256), nn.MaxPool2d(2,2),
            conv_bn_lrelu(256, 512), conv_bn_lrelu(512, 256, 1), conv_bn_lrelu(256, 512),
        )
        self.use_biformer = use_biformer
        if use_biformer:
            self.stage1 = nn.Sequential(*[
                BiFormerBlock(512, biformer_heads, biformer_topk, biformer_regions)
                for _ in range(biformer_depth)
            ])
        else:
            self.stage1 = nn.Sequential(*[conv_bn_lrelu(512, 512) for _ in range(biformer_depth)])
        self.down = nn.Sequential(nn.MaxPool2d(2,2), conv_bn_lrelu(512, 1024), conv_bn_lrelu(1024, 512, 1), conv_bn_lrelu(512, 1024))
        self.out_proj = nn.Conv2d(1024, out_dim, 1)

    def forward(self, x):
        x = self.stem(x)
        x = self.stage1(x)
        x = self.down(x)
        return self.out_proj(x)


class ResNeXtBottleneck3D(nn.Module):
    expansion = 2
    def __init__(self, inplanes, planes, stride=(1,1,1), groups=32, width_per_group=4,
                 use_se=True, se_reduction=16):
        super().__init__()
        width = int(planes * (width_per_group / 64.0)) * groups
        self.conv1 = nn.Conv3d(inplanes, width, 1, bias=False)
        self.bn1 = nn.BatchNorm3d(width)
        self.conv2 = nn.Conv3d(width, width, 3, stride=stride, padding=1, groups=groups, bias=False)
        self.bn2 = nn.BatchNorm3d(width)
        self.conv3 = nn.Conv3d(width, planes * self.expansion, 1, bias=False)
        self.bn3 = nn.BatchNorm3d(planes * self.expansion)
        self.se = SE3D(planes * self.expansion, se_reduction) if use_se else nn.Identity()
        if stride != (1,1,1) or inplanes != planes * self.expansion:
            self.downsample = nn.Sequential(
                nn.Conv3d(inplanes, planes * self.expansion, 1, stride=stride, bias=False),
                nn.BatchNorm3d(planes * self.expansion),
            )
        else:
            self.downsample = nn.Identity()
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        identity = self.downsample(x)
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.relu(self.bn2(self.conv2(out)))
        out = self.bn3(self.conv3(out))
        out = self.se(out)
        out = self.relu(out + identity)
        return out


class ResNeXt3D(nn.Module):
    """3D-ResNeXt-101-style temporal backbone with optional SE in each residual block."""
    def __init__(self, out_dim=512, layers: Sequence[int] = (3,4,23,3), groups=32,
                 width_per_group=4, use_se=True, se_reduction=16):
        super().__init__()
        self.inplanes = 64
        self.stem = nn.Sequential(
            nn.Conv3d(3, 64, kernel_size=(3,7,7), stride=(1,2,2), padding=(1,3,3), bias=False),
            nn.BatchNorm3d(64), nn.ReLU(inplace=True),
            nn.MaxPool3d(kernel_size=(1,3,3), stride=(1,2,2), padding=(0,1,1)),
        )
        self.layer1 = self._make_layer(128, layers[0], stride=(2,1,1), groups=groups, width=width_per_group, use_se=use_se, red=se_reduction)
        self.layer2 = self._make_layer(256, layers[1], stride=(2,2,2), groups=groups, width=width_per_group, use_se=use_se, red=se_reduction)
        self.layer3 = self._make_layer(512, layers[2], stride=(2,2,2), groups=groups, width=width_per_group, use_se=use_se, red=se_reduction)
        self.layer4 = self._make_layer(1024, layers[3], stride=(2,2,2), groups=groups, width=width_per_group, use_se=use_se, red=se_reduction)
        self.out_proj = nn.Conv2d(2048, out_dim, 1)

    def _make_layer(self, planes, blocks, stride, groups, width, use_se, red):
        seq = [ResNeXtBottleneck3D(self.inplanes, planes, stride, groups, width, use_se, red)]
        self.inplanes = planes * ResNeXtBottleneck3D.expansion
        for _ in range(1, blocks):
            seq.append(ResNeXtBottleneck3D(self.inplanes, planes, (1,1,1), groups, width, use_se, red))
        return nn.Sequential(*seq)

    def forward(self, x):
        x = self.stem(x)
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        x = x.mean(dim=2)  # temporal aggregation to 2D feature map
        return self.out_proj(x)
