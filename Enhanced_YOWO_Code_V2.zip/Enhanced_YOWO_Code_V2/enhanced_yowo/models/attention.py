import math
from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F


class SE2D(nn.Module):
    def __init__(self, channels: int, reduction: int = 16):
        super().__init__()
        hidden = max(8, channels // reduction)
        self.fc1 = nn.Conv2d(channels, hidden, 1)
        self.fc2 = nn.Conv2d(hidden, channels, 1)

    def forward(self, x):
        w = F.adaptive_avg_pool2d(x, 1)
        w = F.relu(self.fc1(w), inplace=True)
        w = torch.sigmoid(self.fc2(w))
        return x * w


class SE3D(nn.Module):
    def __init__(self, channels: int, reduction: int = 16):
        super().__init__()
        hidden = max(8, channels // reduction)
        self.fc1 = nn.Conv3d(channels, hidden, 1)
        self.fc2 = nn.Conv3d(hidden, channels, 1)

    def forward(self, x):
        w = F.adaptive_avg_pool3d(x, 1)
        w = F.relu(self.fc1(w), inplace=True)
        w = torch.sigmoid(self.fc2(w))
        return x * w


class ChannelAttention(nn.Module):
    """Channel attention used as CAM in the DCEM implementation."""
    def __init__(self, channels: int, reduction: int = 16):
        super().__init__()
        hidden = max(8, channels // reduction)
        self.mlp = nn.Sequential(
            nn.Conv2d(channels, hidden, 1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(hidden, channels, 1, bias=False),
        )

    def forward(self, x):
        avg = self.mlp(F.adaptive_avg_pool2d(x, 1))
        mx = self.mlp(F.adaptive_max_pool2d(x, 1))
        return x * torch.sigmoid(avg + mx)


class EMA(nn.Module):
    """
    Efficient Multi-Scale Attention with grouped cross-spatial learning.
    This follows the main structure of Ouyang et al. (ICASSP 2023): grouped
    channels, horizontal/vertical pooling, a local 3x3 branch, and cross-spatial
    weighting. Input/output shapes are identical.
    """
    def __init__(self, channels: int, groups: int = 32):
        super().__init__()
        groups = min(groups, channels)
        while channels % groups != 0 and groups > 1:
            groups -= 1
        self.groups = groups
        c = channels // groups
        self.softmax = nn.Softmax(dim=-1)
        self.agp = nn.AdaptiveAvgPool2d((1, 1))
        self.gn = nn.GroupNorm(c, c)
        self.conv1x1 = nn.Conv2d(c, c, kernel_size=1, stride=1, padding=0)
        self.conv3x3 = nn.Conv2d(c, c, kernel_size=3, stride=1, padding=1)

    def forward(self, x):
        b, c, h, w = x.shape
        g = self.groups
        group_x = x.reshape(b * g, c // g, h, w)
        x_h = group_x.mean(dim=3, keepdim=True)  # BG,Cg,H,1
        x_w = group_x.mean(dim=2, keepdim=True).transpose(2, 3)  # BG,Cg,W,1
        hw = self.conv1x1(torch.cat([x_h, x_w], dim=2))
        x_h2, x_w2 = torch.split(hw, [h, w], dim=2)
        gated = group_x * torch.sigmoid(x_h2) * torch.sigmoid(x_w2.transpose(2, 3))
        x1 = self.gn(gated)
        x2 = self.conv3x3(group_x)

        p1 = self.softmax(self.agp(x1).reshape(b * g, 1, -1))
        p2 = self.softmax(self.agp(x2).reshape(b * g, 1, -1))
        f1 = x1.reshape(b * g, c // g, -1)
        f2 = x2.reshape(b * g, c // g, -1)
        spatial = torch.bmm(p1, f2) + torch.bmm(p2, f1)
        spatial = spatial.reshape(b * g, 1, h, w)
        out = group_x * torch.sigmoid(spatial)
        return out.reshape(b, c, h, w)


class BiLevelRoutingAttention(nn.Module):
    """
    Compact BiFormer-style bi-level routing attention.

    1) Feature maps are partitioned into region grids.
    2) Region-level Q/K summaries route each query region to top-k key regions.
    3) Token attention is only computed over routed key/value tokens.

    It is intentionally self-contained so the project does not depend on an
    external BiFormer repository.
    """
    def __init__(self, dim: int, num_heads: int = 8, topk: int = 4, n_win: int = 3,
                 qkv_bias: bool = True, proj_drop: float = 0.0):
        super().__init__()
        assert dim % num_heads == 0
        self.dim = dim
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        self.scale = self.head_dim ** -0.5
        self.topk = topk
        self.n_win = n_win
        self.qkv = nn.Conv2d(dim, dim * 3, 1, bias=qkv_bias)
        self.proj = nn.Conv2d(dim, dim, 1)
        self.drop = nn.Dropout(proj_drop)
        self.lepe = nn.Conv2d(dim, dim, 3, padding=1, groups=dim)

    def _pad_to_regions(self, x):
        b, c, h, w = x.shape
        rh = math.ceil(h / self.n_win)
        rw = math.ceil(w / self.n_win)
        hp, wp = rh * self.n_win, rw * self.n_win
        x = F.pad(x, (0, wp - w, 0, hp - h))
        return x, h, w, rh, rw

    def forward(self, x):
        residual = self.lepe(x)
        x_pad, h0, w0, rh, rw = self._pad_to_regions(x)
        b, c, hp, wp = x_pad.shape
        q, k, v = self.qkv(x_pad).chunk(3, dim=1)

        # B,C,nw,nw,rh,rw -> B,R,T,C
        def regions(t):
            t = t.view(b, c, self.n_win, rh, self.n_win, rw)
            t = t.permute(0, 2, 4, 3, 5, 1).contiguous()
            return t.view(b, self.n_win * self.n_win, rh * rw, c)

        qr, kr, vr = regions(q), regions(k), regions(v)
        q_reg = qr.mean(dim=2)
        k_reg = kr.mean(dim=2)
        route = torch.matmul(q_reg, k_reg.transpose(-1, -2)) / math.sqrt(c)
        k_top = min(self.topk, route.shape[-1])
        top_idx = route.topk(k=k_top, dim=-1).indices  # B,R,K

        outs = []
        for r in range(qr.shape[1]):
            q_tokens = qr[:, r]  # B,T,C
            idx = top_idx[:, r]  # B,K
            gathered_k, gathered_v = [], []
            for bi in range(b):
                gathered_k.append(kr[bi, idx[bi]].reshape(-1, c))
                gathered_v.append(vr[bi, idx[bi]].reshape(-1, c))
            k_tokens = torch.stack(gathered_k, dim=0)
            v_tokens = torch.stack(gathered_v, dim=0)

            def split_heads(t):
                return t.view(b, t.shape[1], self.num_heads, self.head_dim).transpose(1, 2)

            qh, kh, vh = split_heads(q_tokens), split_heads(k_tokens), split_heads(v_tokens)
            attn = torch.matmul(qh, kh.transpose(-2, -1)) * self.scale
            attn = attn.softmax(dim=-1)
            out = torch.matmul(attn, vh).transpose(1, 2).reshape(b, rh * rw, c)
            outs.append(out)

        out = torch.stack(outs, dim=1)
        out = out.view(b, self.n_win, self.n_win, rh, rw, c)
        out = out.permute(0, 5, 1, 3, 2, 4).contiguous().view(b, c, hp, wp)
        out = out[:, :, :h0, :w0]
        return self.drop(self.proj(out)) + residual


class BiFormerBlock(nn.Module):
    def __init__(self, dim: int, heads: int = 8, topk: int = 4, n_win: int = 3,
                 mlp_ratio: float = 4.0):
        super().__init__()
        self.norm1 = nn.GroupNorm(1, dim)
        self.attn = BiLevelRoutingAttention(dim, heads, topk, n_win)
        self.norm2 = nn.GroupNorm(1, dim)
        hidden = int(dim * mlp_ratio)
        self.mlp = nn.Sequential(
            nn.Conv2d(dim, hidden, 1), nn.GELU(),
            nn.Conv2d(hidden, dim, 1),
        )

    def forward(self, x):
        x = x + self.attn(self.norm1(x))
        x = x + self.mlp(self.norm2(x))
        return x
