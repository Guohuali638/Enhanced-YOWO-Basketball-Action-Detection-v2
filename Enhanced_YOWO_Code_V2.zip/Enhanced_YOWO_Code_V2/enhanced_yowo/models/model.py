from typing import Dict, Tuple
import torch
import torch.nn as nn
import torch.nn.functional as F

from .backbones import DarknetSpatialBranch, ResNeXt3D
from .dcem import DCEM


class EnhancedYOWO(nn.Module):
    def __init__(self, num_classes: int, anchors, model_cfg: Dict):
        super().__init__()
        self.num_classes = num_classes
        self.register_buffer("anchors", torch.tensor(anchors, dtype=torch.float32))
        self.num_anchors = len(anchors)
        sd = model_cfg.get("spatial_dim", 512)
        td = model_cfg.get("temporal_dim", 512)
        fd = model_cfg.get("fusion_dim", sd + td)
        self.spatial = DarknetSpatialBranch(
            out_dim=sd,
            use_biformer=model_cfg.get("use_biformer", True),
            biformer_heads=model_cfg.get("biformer_heads", 8),
            biformer_topk=model_cfg.get("biformer_topk", 4),
            biformer_regions=model_cfg.get("biformer_regions", 3),
            biformer_depth=model_cfg.get("biformer_depth", 2),
        )
        self.temporal = ResNeXt3D(
            out_dim=td,
            layers=model_cfg.get("temporal_layers", [3,4,23,3]),
            groups=model_cfg.get("temporal_groups", 32),
            width_per_group=model_cfg.get("temporal_width_per_group", 4),
            use_se=model_cfg.get("use_se", True),
            se_reduction=model_cfg.get("se_reduction", 16),
        )
        self.align_s = nn.Conv2d(sd, fd // 2, 1)
        self.align_t = nn.Conv2d(td, fd - fd // 2, 1)
        self.dcem = DCEM(fd, model_cfg.get("dcem_variant", "asymmetric"), model_cfg.get("ema_groups", 32))
        self.head = nn.Sequential(
            nn.Conv2d(fd, fd // 2, 3, padding=1, bias=False),
            nn.BatchNorm2d(fd // 2), nn.LeakyReLU(0.1, inplace=True),
            nn.Conv2d(fd // 2, self.num_anchors * (5 + num_classes), 1),
        )
        self.last_fused = None

    def forward(self, clips: torch.Tensor, return_features: bool = False):
        # clips: B,T,C,H,W
        key = clips[:, clips.shape[1] // 2]
        fs = self.spatial(key)
        ft = self.temporal(clips.permute(0,2,1,3,4).contiguous())
        if ft.shape[-2:] != fs.shape[-2:]:
            ft = F.interpolate(ft, fs.shape[-2:], mode="bilinear", align_corners=False)
        fs = self.align_s(fs)
        ft = self.align_t(ft)
        fused = self.dcem(torch.cat([fs, ft], dim=1))
        self.last_fused = fused
        pred = self.head(fused)
        b, _, h, w = pred.shape
        pred = pred.view(b, self.num_anchors, 5 + self.num_classes, h, w).permute(0,1,3,4,2).contiguous()
        if return_features:
            return pred, fused
        return pred


def build_model(cfg: Dict) -> EnhancedYOWO:
    return EnhancedYOWO(cfg["num_classes"], cfg["anchors"], cfg["model"])


def model_variant_cfg(base_cfg: Dict, use_biformer=None, use_se=None, dcem_variant=None):
    import copy
    cfg = copy.deepcopy(base_cfg)
    if use_biformer is not None:
        cfg["model"]["use_biformer"] = use_biformer
    if use_se is not None:
        cfg["model"]["use_se"] = use_se
    if dcem_variant is not None:
        cfg["model"]["dcem_variant"] = dcem_variant
    return cfg
