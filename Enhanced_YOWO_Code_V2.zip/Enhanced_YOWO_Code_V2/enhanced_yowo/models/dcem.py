import torch
import torch.nn as nn

from .attention import EMA, ChannelAttention


class ConvBlock(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv2d(channels, channels, 1, bias=False),
            nn.BatchNorm2d(channels), nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, 3, padding=1, bias=False),
            nn.BatchNorm2d(channels), nn.ReLU(inplace=True),
        )
    def forward(self, x): return self.net(x)


class DCEM(nn.Module):
    """Supports the structural ablations requested by Reviewer 1."""
    VARIANTS = {
        "original_cam", "single_ema", "single_cam_ema", "symmetric_ema",
        "symmetric_cam_ema", "asymmetric", "none"
    }
    def __init__(self, channels: int, variant: str = "asymmetric", ema_groups: int = 32):
        super().__init__()
        if variant not in self.VARIANTS:
            raise ValueError(f"Unknown DCEM variant {variant}")
        self.variant = variant
        self.pre1 = ConvBlock(channels)
        self.pre2 = ConvBlock(channels)
        self.ema1 = EMA(channels, ema_groups)
        self.ema2 = EMA(channels, ema_groups)
        self.cam1 = ChannelAttention(channels)
        self.cam2 = ChannelAttention(channels)

    def forward(self, x):
        if self.variant == "none":
            return x
        if self.variant == "original_cam":
            return self.cam1(x)
        if self.variant == "single_ema":
            return self.ema1(self.pre1(x))
        if self.variant == "single_cam_ema":
            return self.ema1(self.cam1(self.pre1(x)))
        if self.variant == "symmetric_ema":
            return self.ema1(self.pre1(x)) + self.ema2(self.pre2(x))
        if self.variant == "symmetric_cam_ema":
            return self.ema1(self.cam1(self.pre1(x))) + self.ema2(self.cam2(self.pre2(x)))
        # Proposed asymmetric DCEM: EMA || CAM+EMA
        upper = self.ema1(self.pre1(x))
        lower = self.ema2(self.cam2(self.pre2(x)))
        return upper + lower
