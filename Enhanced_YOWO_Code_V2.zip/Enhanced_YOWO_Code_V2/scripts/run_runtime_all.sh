#!/usr/bin/env bash
set -euo pipefail
ROOT=${1:-runs/basketball_ablation}
for V in baseline biformer se dcem full; do
  python main.py benchmark --config "$ROOT/${V}.yaml" --checkpoint "$ROOT/$V/best.pt" --output "$ROOT/$V/runtime.json" --warmup 100 --runs 500
done
