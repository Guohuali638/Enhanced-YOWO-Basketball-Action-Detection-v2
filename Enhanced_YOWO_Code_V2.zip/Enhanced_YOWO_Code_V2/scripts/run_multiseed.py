#!/usr/bin/env python
import argparse,json,subprocess,sys
from pathlib import Path
import yaml,numpy as np


def run(cmd,log_path):
    log_path.parent.mkdir(parents=True,exist_ok=True)
    print('RUN:', ' '.join(map(str,cmd)))
    with open(log_path,'w',encoding='utf-8') as f:
        p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)
        for line in p.stdout:
            sys.stdout.write(line); f.write(line)
        code=p.wait()
    if code: raise subprocess.CalledProcessError(code,cmd)

def variant_cfg(base,variant,out):
    cfg=yaml.safe_load(open(base,encoding='utf-8'))
    m=cfg['model']
    if variant=='baseline': m.update(use_biformer=False,use_se=False,dcem_variant='original_cam')
    elif variant=='full': m.update(use_biformer=True,use_se=True,dcem_variant='asymmetric')
    else: raise ValueError('variant must be baseline or full')
    out.parent.mkdir(parents=True,exist_ok=True); yaml.safe_dump(cfg,open(out,'w',encoding='utf-8'),sort_keys=False)

def main():
    p=argparse.ArgumentParser(description='Run fixed-split independent random-seed repetitions.')
    p.add_argument('--dataset',choices=['basketball','ucf10124'],required=True)
    p.add_argument('--config',required=True); p.add_argument('--train-manifest',required=True); p.add_argument('--val-manifest',required=True)
    p.add_argument('--variant',choices=['baseline','full'],required=True); p.add_argument('--seeds',type=int,nargs='+',default=[42,123,2026])
    p.add_argument('--output-root',default='results'); p.add_argument('--log-root',default='logs'); p.add_argument('--epochs',type=int,default=None)
    a=p.parse_args(); root=Path(__file__).resolve().parents[1]
    vc=root/'release'/f'{a.dataset}_{a.variant}_resolved_base.yaml'; variant_cfg(a.config,a.variant,vc)
    rows=[]
    for seed in a.seeds:
        run_dir=Path(a.output_root)/a.dataset/a.variant/f'seed_{seed}'; log_dir=Path(a.log_root)/a.dataset/a.variant/f'seed_{seed}'
        train_cmd=[sys.executable,str(root/'train.py'),'--config',str(vc),'--manifest',a.train_manifest,'--val-manifest',a.val_manifest,'--output',str(run_dir),'--seed',str(seed)]
        if a.epochs: train_cmd += ['--epochs',str(a.epochs)]
        run(train_cmd,log_dir/'train.log')
        metrics=run_dir/'metrics.json'
        eval_cmd=[sys.executable,str(root/'evaluate.py'),'--config',str(vc),'--manifest',a.val_manifest,'--checkpoint',str(run_dir/'best.pt'),'--output',str(metrics),'--predictions-output',str(run_dir/'predictions.json')]
        run(eval_cmd,log_dir/'evaluate.log')
        d=json.load(open(metrics,encoding='utf-8')); rows.append({'seed':seed,'frame_map':float(d['frame_map']),'metrics':str(metrics)})
    vals=np.asarray([r['frame_map'] for r in rows],float)
    summary={'dataset':a.dataset,'variant':a.variant,'seeds':a.seeds,'n':len(rows),'frame_map_mean':float(vals.mean()),'frame_map_sd':float(vals.std(ddof=1) if len(vals)>1 else 0.0),'runs':rows}
    sp=Path(a.output_root)/a.dataset/a.variant/'multiseed_summary.json'; sp.parent.mkdir(parents=True,exist_ok=True); json.dump(summary,open(sp,'w',encoding='utf-8'),indent=2)
    print(json.dumps(summary,indent=2))
if __name__=='__main__': main()
