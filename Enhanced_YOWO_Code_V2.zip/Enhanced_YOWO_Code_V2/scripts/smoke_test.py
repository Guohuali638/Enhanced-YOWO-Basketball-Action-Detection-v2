from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0,str(ROOT))

import torch
from enhanced_yowo.models import build_model
from enhanced_yowo.losses import YOWOLoss

cfg={
    'num_classes':8,
    'anchors':[[.05,.1],[.1,.2]],
    'model':{
        'use_biformer':True,'use_se':True,'dcem_variant':'asymmetric',
        'spatial_dim':64,'temporal_dim':64,'fusion_dim':128,
        'biformer_heads':4,'biformer_topk':2,'biformer_regions':2,'biformer_depth':1,
        'temporal_layers':[1,1,1,1],'temporal_groups':4,'temporal_width_per_group':4,
        'se_reduction':8,'ema_groups':8
    }
}
m=build_model(cfg)
x=torch.randn(1,16,3,64,64)
pred=m(x)
crit=YOWOLoss(cfg['anchors'],8,{'box_weight':5,'obj_weight':1,'cls_weight':1,'focal_gamma':2,'focal_alpha':.25})
target=[{'boxes':torch.tensor([[.2,.2,.5,.7]]),'labels':torch.tensor([2])}]
loss,_=crit(pred,target)
assert torch.isfinite(loss)
print('SMOKE_TEST_OK', tuple(pred.shape), float(loss.detach()))
