#!/usr/bin/env python
"""Approximate Conv/Linear FLOPs for one forward pass. Attention matmul FLOPs are not included."""
import argparse,json
from pathlib import Path
import torch
import torch.nn as nn
from enhanced_yowo.models import build_model
from enhanced_yowo.utils.common import load_config,get_device,model_num_parameters


def main():
 p=argparse.ArgumentParser();p.add_argument('--config',required=True);p.add_argument('--output',default=None);a=p.parse_args();cfg=load_config(a.config);dev=get_device(cfg.get('device','cuda'));m=build_model(cfg).to(dev).eval();total={'v':0}
 def hook(mod,inp,out):
  if isinstance(mod,(nn.Conv2d,nn.Conv3d)):
   batch=out.shape[0];out_elems=out.numel()/batch;kernel=1
   for k in mod.kernel_size:kernel*=k
   ops=out_elems*(mod.in_channels/mod.groups)*kernel*2*batch;total['v']+=ops
  elif isinstance(mod,nn.Linear):total['v']+=inp[0].numel()/inp[0].shape[-1]*mod.in_features*mod.out_features*2
 hs=[x.register_forward_hook(hook) for x in m.modules() if isinstance(x,(nn.Conv2d,nn.Conv3d,nn.Linear))]
 x=torch.randn(1,cfg['clip_len'],3,cfg['image_size'],cfg['image_size'],device=dev)
 with torch.no_grad():m(x)
 for h in hs:h.remove()
 r={'parameters_M':model_num_parameters(m)/1e6,'conv_linear_GFLOPs':total['v']/1e9,'note':'BiFormer/EMA explicit tensor-matmul FLOPs are not included; use this only as a consistent implementation-side estimate.'}
 print(json.dumps(r,indent=2));
 if a.output:Path(a.output).parent.mkdir(parents=True,exist_ok=True);json.dump(r,open(a.output,'w'),indent=2)
if __name__=='__main__':main()
