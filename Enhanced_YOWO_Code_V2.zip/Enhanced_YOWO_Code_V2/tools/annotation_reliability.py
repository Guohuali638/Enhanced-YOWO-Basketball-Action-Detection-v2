#!/usr/bin/env python
import argparse, json, math
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import numpy as np
from enhanced_yowo.data.dataset import load_manifest


def iou(a,b):
    x1=max(a[0],b[0]); y1=max(a[1],b[1]); x2=min(a[2],b[2]); y2=min(a[3],b[3])
    inter=max(0,x2-x1)*max(0,y2-y1)
    aa=max(0,a[2]-a[0])*max(0,a[3]-a[1]); bb=max(0,b[2]-b[0])*max(0,b[3]-b[1])
    return inter/max(aa+bb-inter,1e-12)

def norm_boxes(v,ann):
    b=np.asarray(ann.get('boxes',[]),dtype=float).reshape(-1,4)
    if len(b) and b.max()>1.5:
        b[:,[0,2]]/=float(v.get('width',1)); b[:,[1,3]]/=float(v.get('height',1))
    return b.tolist()

def index_manifest(m):
    out={}
    for v in m['videos']:
        for a in v.get('annotations',[]): out[(v['video_id'],int(a['frame_index']))]=(v,a)
    return out

def cohen_kappa(a,b,num_classes=None):
    if len(a)==0: return float('nan')
    a=np.asarray(a,int); b=np.asarray(b,int)
    classes=sorted(set(a.tolist())|set(b.tolist())) if num_classes is None else list(range(num_classes))
    po=float(np.mean(a==b)); n=len(a)
    pe=0.0
    for c in classes: pe += float(np.sum(a==c)/n)*float(np.sum(b==c)/n)
    return (po-pe)/(1-pe) if abs(1-pe)>1e-12 else 1.0

def main():
    p=argparse.ArgumentParser(description='Compute real inter-annotator agreement for two independently annotated manifests.')
    p.add_argument('--reference',required=True); p.add_argument('--second',required=True); p.add_argument('--output',required=True)
    p.add_argument('--match-iou',type=float,default=0.5); p.add_argument('--num-classes',type=int,default=None)
    a=p.parse_args(); ma=load_manifest(a.reference); mb=load_manifest(a.second)
    ia=index_manifest(ma); ib=index_manifest(mb); keys=sorted(set(ia)&set(ib))
    if not keys: raise ValueError('No common video_id/frame_index pairs between annotation files')
    labs_a=[]; labs_b=[]; matched_ious=[]; total_a=total_b=matched=0
    per_frame=[]
    for k in keys:
        va,aa=ia[k]; vb,ab=ib[k]; ba=norm_boxes(va,aa); bb=norm_boxes(vb,ab); la=list(map(int,aa.get('labels',[]))); lb=list(map(int,ab.get('labels',[])))
        total_a+=len(ba); total_b+=len(bb); used=set(); fm=[]
        candidates=[]
        for i,x in enumerate(ba):
            for j,y in enumerate(bb): candidates.append((iou(x,y),i,j))
        for ov,i,j in sorted(candidates,reverse=True):
            if ov<a.match_iou or i in {x[0] for x in fm} or j in used: continue
            fm.append((i,j,ov)); used.add(j); matched+=1; matched_ious.append(ov); labs_a.append(la[i]); labs_b.append(lb[j])
        per_frame.append({'video_id':k[0],'frame_index':k[1],'n_reference':len(ba),'n_second':len(bb),'matched':len(fm)})
    kappa=cohen_kappa(labs_a,labs_b,a.num_classes)
    out={'common_frames':len(keys),'reference_boxes':total_a,'second_annotator_boxes':total_b,'matched_boxes':matched,
         'box_match_iou_threshold':a.match_iou,'reference_match_rate':matched/max(total_a,1),'second_match_rate':matched/max(total_b,1),
         'mean_matched_box_iou':float(np.mean(matched_ious)) if matched_ious else None,
         'median_matched_box_iou':float(np.median(matched_ious)) if matched_ious else None,
         'matched_label_agreement':float(np.mean(np.asarray(labs_a)==np.asarray(labs_b))) if labs_a else None,
         'cohen_kappa_on_matched_boxes':None if math.isnan(kappa) else float(kappa),
         'per_frame':per_frame,
         'interpretation_note':'These statistics are valid only if the second annotation was genuinely independent and the sampled-frame protocol is documented.'}
    Path(a.output).parent.mkdir(parents=True,exist_ok=True); json.dump(out,open(a.output,'w',encoding='utf-8'),indent=2,ensure_ascii=False)
    print(json.dumps({k:v for k,v in out.items() if k!='per_frame'},indent=2))
if __name__=='__main__': main()
