#!/usr/bin/env python
import argparse, json
from pathlib import Path
import numpy as np
import yaml
from sklearn.cluster import KMeans


def main():
    p=argparse.ArgumentParser(description='Compute five normalized width/height anchors from the actual annotations.')
    p.add_argument('--manifest',required=True); p.add_argument('--k',type=int,default=5); p.add_argument('--seed',type=int,default=42)
    p.add_argument('--output',default=None,help='Optional JSON output file')
    p.add_argument('--update-config',default=None,help='Optional YAML config to update in-place with the computed anchors')
    a=p.parse_args(); m=json.load(open(a.manifest,encoding='utf-8')); wh=[]
    for v in m['videos']:
        W=float(v.get('width',1)); H=float(v.get('height',1))
        for ann in v.get('annotations',[]):
            for b in ann.get('boxes',[]):
                x1,y1,x2,y2=map(float,b); w=x2-x1; h=y2-y1
                if max(b)>1.5: w/=W; h/=H
                if w>0 and h>0: wh.append([w,h])
    if len(wh)<a.k: raise ValueError(f'Need at least {a.k} valid boxes; found {len(wh)}')
    x=np.asarray(wh); km=KMeans(n_clusters=a.k,random_state=a.seed,n_init=20).fit(x)
    centers=km.cluster_centers_; centers=centers[np.argsort(centers.prod(1))]
    anchors=[[float(z[0]),float(z[1])] for z in centers]
    result={'manifest':str(Path(a.manifest).resolve()),'k':a.k,'seed':a.seed,'num_boxes':len(wh),'anchors':anchors}
    print(yaml.safe_dump({'anchors':anchors},sort_keys=False).strip())
    if a.output:
        Path(a.output).parent.mkdir(parents=True,exist_ok=True); json.dump(result,open(a.output,'w',encoding='utf-8'),indent=2)
    if a.update_config:
        cfg=yaml.safe_load(open(a.update_config,encoding='utf-8')); cfg['anchors']=anchors; cfg['anchors_verified_from_manifest']=True; cfg['anchors_source_manifest']=str(Path(a.manifest).resolve())
        yaml.safe_dump(cfg,open(a.update_config,'w',encoding='utf-8'),sort_keys=False)
        print('Updated config:',a.update_config)
if __name__=='__main__': main()
