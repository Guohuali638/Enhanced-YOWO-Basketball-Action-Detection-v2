#!/usr/bin/env python
import argparse, csv, json
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import numpy as np

from enhanced_yowo.data.dataset import load_manifest, save_manifest


def key_rows(manifest):
    rows=[]
    for v in manifest['videos']:
        sid=v.get('source_id',v['video_id'])
        for a in v.get('annotations',[]):
            rows.append((v['video_id'],sid,int(a['frame_index'])))
    return rows


def write_csv(path, rows):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(['video_id','source_id','frame_index']); w.writerows(rows)


def filtered_manifest(m, allowed_keys=None, allowed_sources=None):
    base={k:v for k,v in m.items() if k!='videos'}
    out=dict(base); out['videos']=[]
    aks=set(allowed_keys) if allowed_keys is not None else None
    ass=set(allowed_sources) if allowed_sources is not None else None
    for v in m['videos']:
        sid=v.get('source_id',v['video_id'])
        if ass is not None and sid not in ass: continue
        nv={k:val for k,val in v.items() if k!='annotations'}
        anns=[]
        for a in v.get('annotations',[]):
            k=(v['video_id'],int(a['frame_index']))
            if aks is None or k in aks: anns.append(a)
        if anns:
            nv['annotations']=anns; out['videos'].append(nv)
    return out


def main():
    p=argparse.ArgumentParser(description='Export exact basketball frame split and leave-one-source folds.')
    p.add_argument('--manifest',required=True)
    p.add_argument('--output-dir',required=True)
    p.add_argument('--train-ratio',type=float,default=0.7911609488332408)
    p.add_argument('--split-seed',type=int,default=42)
    a=p.parse_args()
    out=Path(a.output_dir); out.mkdir(parents=True,exist_ok=True)
    m=load_manifest(a.manifest)
    rows=key_rows(m)
    if not rows: raise ValueError('No annotated frames in manifest')
    rng=np.random.RandomState(a.split_seed); order=np.arange(len(rows)); rng.shuffle(order)
    n=int(len(rows)*a.train_ratio); tr=[rows[i] for i in order[:n]]; va=[rows[i] for i in order[n:]]
    write_csv(out/'basketball_frame_train.csv',tr); write_csv(out/'basketball_frame_val.csv',va)
    tr_keys={(r[0],r[2]) for r in tr}; va_keys={(r[0],r[2]) for r in va}
    save_manifest(filtered_manifest(m,allowed_keys=tr_keys),out/'basketball_frame_train.json')
    save_manifest(filtered_manifest(m,allowed_keys=va_keys),out/'basketball_frame_val.json')
    sources=sorted({v.get('source_id',v['video_id']) for v in m['videos']})
    fold_index=[]
    for i,val in enumerate(sources,1):
        train=[s for s in sources if s!=val]
        fd=out/f'basketball_lovo_fold{i}'; fd.mkdir(exist_ok=True)
        save_manifest(filtered_manifest(m,allowed_sources=train),fd/'train.json')
        save_manifest(filtered_manifest(m,allowed_sources=[val]),fd/'val.json')
        (fd/'train_sources.txt').write_text('\n'.join(train)+'\n',encoding='utf-8')
        (fd/'val_source.txt').write_text(val+'\n',encoding='utf-8')
        fold_index.append({'fold':i,'train_sources':train,'validation_source':val})
    summary={'manifest':str(Path(a.manifest).resolve()),'split_seed':a.split_seed,'train_ratio':a.train_ratio,
             'num_total_frames':len(rows),'num_train_frames':len(tr),'num_val_frames':len(va),
             'sources':sources,'leave_one_source_out_folds':fold_index}
    json.dump(summary,open(out/'split_summary.json','w',encoding='utf-8'),indent=2,ensure_ascii=False)
    print(json.dumps(summary,indent=2))

if __name__=='__main__': main()
