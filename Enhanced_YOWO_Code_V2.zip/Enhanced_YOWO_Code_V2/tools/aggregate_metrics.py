#!/usr/bin/env python
import argparse,json
from pathlib import Path
import numpy as np

def get_path(d,path):
    x=d
    for p in path.split('.'):
        x=x[p]
    return float(x)

def main():
    p=argparse.ArgumentParser(); p.add_argument('--inputs',nargs='+',required=True); p.add_argument('--metric',default='frame_map'); p.add_argument('--output',required=True)
    a=p.parse_args(); vals=[]; rows=[]
    for fn in a.inputs:
        d=json.load(open(fn,encoding='utf-8')); v=get_path(d,a.metric); vals.append(v); rows.append({'file':fn,'value':v})
    arr=np.asarray(vals,float); out={'metric':a.metric,'n':len(vals),'mean':float(arr.mean()),'sd':float(arr.std(ddof=1) if len(arr)>1 else 0.0),'runs':rows}
    Path(a.output).parent.mkdir(parents=True,exist_ok=True); json.dump(out,open(a.output,'w',encoding='utf-8'),indent=2); print(json.dumps(out,indent=2))
if __name__=='__main__': main()
