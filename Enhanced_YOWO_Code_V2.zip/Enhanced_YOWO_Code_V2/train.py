#!/usr/bin/env python
import argparse
import csv
import hashlib
import json
import os
import platform
import socket
import sys
from datetime import datetime, timezone
from pathlib import Path

import torch
from torch.utils.data import DataLoader
from torch.cuda.amp import GradScaler

from enhanced_yowo.data import VideoActionDataset, detection_collate, random_frame_split_keys
from enhanced_yowo.models import build_model
from enhanced_yowo.losses import YOWOLoss
from enhanced_yowo.engine import train_one_epoch, evaluate_frame
from enhanced_yowo.utils.common import load_config, set_seed, get_device, load_partial_weights, model_num_parameters
from enhanced_yowo.utils.checkpoint import save_checkpoint


class Tee:
    def __init__(self, *streams):
        self.streams = streams
    def write(self, data):
        for stream in self.streams:
            stream.write(data)
        return len(data)
    def flush(self):
        for stream in self.streams:
            stream.flush()
    def isatty(self):
        return any(getattr(stream, 'isatty', lambda: False)() for stream in self.streams)



def parse_args():
    p = argparse.ArgumentParser(description='Train Enhanced YOWO with auditable run metadata')
    p.add_argument('--config', required=True)
    p.add_argument('--manifest', required=True)
    p.add_argument('--output', required=True)
    p.add_argument('--val-manifest', default=None)
    p.add_argument('--train-sources', nargs='*', default=None)
    p.add_argument('--val-sources', nargs='*', default=None)
    p.add_argument('--frame-split', action='store_true', help='Use a deterministic ~4:1 random frame split from one manifest')
    p.add_argument('--weights2d', default=None)
    p.add_argument('--weights3d', default=None)
    p.add_argument('--resume', default=None)
    p.add_argument('--no-amp', action='store_true')
    p.add_argument('--epochs', type=int, default=None)
    p.add_argument('--seed', type=int, default=None)
    return p.parse_args()


def make_dataset(cfg, manifest, training, allowed_sources=None, allowed_keys=None):
    aug = cfg.get('augmentation', {})
    return VideoActionDataset(
        manifest, cfg['image_size'], cfg['clip_len'], cfg.get('frame_stride', 1), training,
        aug.get('horizontal_flip', 0) if training else 0,
        aug.get('vertical_flip', 0) if training else 0,
        aug.get('color_jitter', 0) if training else 0,
        allowed_sources=allowed_sources, allowed_keys=allowed_keys,
    )


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def environment_metadata(device):
    meta = {
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'command': sys.argv,
        'cwd': os.getcwd(),
        'hostname': socket.gethostname(),
        'platform': platform.platform(),
        'python': sys.version,
        'torch': torch.__version__,
        'cuda_runtime_reported_by_torch': torch.version.cuda,
        'cudnn': torch.backends.cudnn.version(),
        'device': str(device),
        'cuda_available': torch.cuda.is_available(),
    }
    if torch.cuda.is_available():
        meta['gpu_name'] = torch.cuda.get_device_name(device)
        props = torch.cuda.get_device_properties(device)
        meta['gpu_total_memory_gb'] = props.total_memory / 1024**3
    return meta


def write_history_csv(rows, path):
    if not rows:
        return
    keys = list(rows[0].keys())
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader(); w.writerows(rows)


def main():
    a = parse_args(); cfg = load_config(a.config)
    if a.seed is not None: cfg['seed'] = a.seed
    if a.epochs is not None: cfg['epochs'] = a.epochs
    set_seed(cfg.get('seed', 42), cfg.get('deterministic', True))
    device = get_device(cfg.get('device', 'cuda'))
    out = Path(a.output); out.mkdir(parents=True, exist_ok=True)
    # Keep a complete console log inside every training run even when the caller does not redirect stdout.
    _log_fh = open(out/'train.log', 'a', encoding='utf-8', buffering=1)
    sys.stdout = Tee(sys.stdout, _log_fh); sys.stderr = Tee(sys.stderr, _log_fh)

    with open(out/'resolved_config.json', 'w', encoding='utf-8') as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)
    meta = environment_metadata(device)
    meta.update({
        'config_path': str(Path(a.config).resolve()),
        'manifest_path': str(Path(a.manifest).resolve()),
        'manifest_sha256': sha256(a.manifest),
        'val_manifest_path': str(Path(a.val_manifest).resolve()) if a.val_manifest else None,
        'val_manifest_sha256': sha256(a.val_manifest) if a.val_manifest else None,
        'seed': int(cfg.get('seed', 42)),
        'deterministic_requested': bool(cfg.get('deterministic', True)),
        'vertical_flip_probability': float(cfg.get('augmentation', {}).get('vertical_flip', 0.0)),
        'weights2d': a.weights2d,
        'weights3d': a.weights3d,
    })
    json.dump(meta, open(out/'run_metadata.json', 'w', encoding='utf-8'), indent=2, ensure_ascii=False)

    split_info = {}
    if a.val_manifest:
        train_ds = make_dataset(cfg, a.manifest, True, a.train_sources)
        val_ds = make_dataset(cfg, a.val_manifest, False, a.val_sources)
        split_info = {'type':'explicit_manifests','train_manifest':a.manifest,'val_manifest':a.val_manifest,
                      'train_sources':a.train_sources,'val_sources':a.val_sources}
    elif a.frame_split:
        tr, va = random_frame_split_keys(a.manifest, 0.8, cfg.get('seed', 42))
        train_ds = make_dataset(cfg, a.manifest, True, allowed_keys=tr)
        val_ds = make_dataset(cfg, a.manifest, False, allowed_keys=va)
        # Save the exact split used in this run.
        json.dump(sorted([{'video_id':v,'frame_index':i} for v,i in tr], key=lambda x:(x['video_id'],x['frame_index'])), open(out/'train_split_keys.json','w',encoding='utf-8'), indent=2)
        json.dump(sorted([{'video_id':v,'frame_index':i} for v,i in va], key=lambda x:(x['video_id'],x['frame_index'])), open(out/'val_split_keys.json','w',encoding='utf-8'), indent=2)
        split_info = {'type':'random_frame_split','ratio':0.8,'split_seed':int(cfg.get('seed',42)),
                      'train_key_count':len(tr),'val_key_count':len(va)}
    else:
        train_ds = make_dataset(cfg, a.manifest, True, a.train_sources)
        val_ds = make_dataset(cfg, a.manifest, False, a.val_sources)
        split_info = {'type':'source_filters_or_same_manifest','train_sources':a.train_sources,'val_sources':a.val_sources}
    json.dump(split_info, open(out/'split_used.json','w',encoding='utf-8'), indent=2)

    train_loader = DataLoader(train_ds, batch_size=cfg['batch_size'], shuffle=True, num_workers=cfg['num_workers'], pin_memory=True, collate_fn=detection_collate, drop_last=False)
    val_loader = DataLoader(val_ds, batch_size=cfg['batch_size'], shuffle=False, num_workers=cfg['num_workers'], pin_memory=True, collate_fn=detection_collate)

    model = build_model(cfg).to(device)
    print(f'Trainable parameters: {model_num_parameters(model)/1e6:.2f} M')
    if a.weights2d:
        pre2 = load_partial_weights(model.spatial, a.weights2d); print('2D pretrained:', pre2)
        json.dump(pre2, open(out/'pretrained_2d_load.json','w',encoding='utf-8'), indent=2)
    if a.weights3d:
        pre3 = load_partial_weights(model.temporal, a.weights3d); print('3D pretrained:', pre3)
        json.dump(pre3, open(out/'pretrained_3d_load.json','w',encoding='utf-8'), indent=2)

    criterion = YOWOLoss(cfg['anchors'], cfg['num_classes'], cfg['loss']).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=cfg['learning_rate'], weight_decay=cfg['weight_decay'])
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max(1, cfg['epochs']), eta_min=cfg.get('scheduler', {}).get('min_lr', 1e-6))
    scaler = GradScaler(enabled=(not a.no_amp and device.type == 'cuda'))
    start, best = 0, -1
    if a.resume:
        ck = torch.load(a.resume, map_location='cpu')
        model.load_state_dict(ck['model']); optimizer.load_state_dict(ck['optimizer'])
        if 'scheduler' in ck: scheduler.load_state_dict(ck['scheduler'])
        start = ck.get('epoch', 0) + 1; best = ck.get('best_metric', -1)

    log = []
    for epoch in range(start, cfg['epochs']):
        tr = train_one_epoch(model, train_loader, optimizer, criterion, device, scaler, not a.no_amp)
        fm, pc, _ = evaluate_frame(model, val_loader, cfg, device)
        scheduler.step()
        row = {'epoch': epoch + 1, **tr, 'frame_map': fm, 'lr': optimizer.param_groups[0]['lr']}
        log.append(row); print(row)
        json.dump(log, open(out/'history.json', 'w', encoding='utf-8'), indent=2)
        write_history_csv(log, out/'history.csv')
        save_checkpoint(out/'last.pt', model, optimizer, scheduler, epoch, best)
        if fm > best:
            best = fm
            save_checkpoint(out/'best.pt', model, optimizer, scheduler, epoch, best)
            json.dump({'best_epoch':epoch+1,'best_frame_map':float(best),'per_class_ap':{str(k):float(v) for k,v in pc.items()}}, open(out/'best_metrics.json','w',encoding='utf-8'), indent=2)
    print('Best Frame-mAP:', best)


if __name__ == '__main__':
    main()
